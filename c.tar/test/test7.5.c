/*rewrite post fix calculator to use scanf or sscanf to do input no conversion*/
#include<stdio.h>
#include<string.h>
int pop(void);
void push(int);
int stack[10];
main()
{
	int n1,n2,op,top=0;
	char str[20];
	printf("enter string\n");
	scanf("%s",str);
	while(sscanf(str,"%d %d %c",n1,n2,op))
	{
		switch(op)
		{
			case '+':stack[top++]=n1+n2;
				 break;
			case '-':stack[top++]=n1-n2;
				 break;
			case '*':stack[top++]=n1*n2;
				 break;
		}
	}
	if(sscanf(str,%c,op))
	{
		switch(op)
		{
			case '+':push(pop()+pop());
				 break;
			case '-':push(pop()-pop());
				 break;
			case '*':push(pop()*pop());
				 break;
		}
	}
	printf("%d",stack[0]);
}
void push(int a)
{
	stack[top++]=a;
}
int pop(void)
{
	return stack[--top];
}


