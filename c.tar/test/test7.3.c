/*revise minprintf to handle more of the other facilities of printf*/
#include<stdio.h>
#include<stdarg.h>
void minprintf(char *fmt,...)
{
	va_list ap;
	char *p,*sval;
	int ival;
	float fval;
	va_start(ap,fmt);
		for(p=fmt;*p;p++)
		{
			if(*p=='%')
			{
			switch(*++p)
			{
				case 'd':ival=va_arg(ap,int);
					 printf("%d",ival);
					 break;
				case 'f':fval=va_arg(ap,double);
					 printf("%f",fval);
					 break;
				case 's':
				 for(sval=va_arg(ap,char *);*sval;sval++)
					 putchar(*sval);
				 break;
				default:putchar(*p);
					break;
			}
			}
			else if(*p=='\\')
			{
				switch(*++p)
				{
					case 'n':putchar('\n');
						 break;
					case 't':putchar('\t');
						 break;
					case 'b':putchar('\b');
						 break;
					default:putchar(*p);
						break;
				}
			}
			else
			{
				putchar(*p);
			}
		}
	va_end(ap);
}
int main()
{
	char c='a';
	int i=10;
	minprintf("%d\n",i);
}
