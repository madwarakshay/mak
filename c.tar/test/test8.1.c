/*rewrite program cat using read,write open and close calls*/
#include<stdio.h>
#include<sys/file.h>
int main(int argc,char **argv)
{
	char buff[100];
	int fd1,fd2,n;
	if((fd1=open(argv[1],O_RDONLY,0))==-1)
		error("cannot open file");
	if((fd2=creat(argv[2],0666))==-1)
		error("cannot create file");
	n=read(fd1,buff,sizeof(buff));
	if(write(fd2,buff,n)!=n)
		error("write error on file %s",argv[2]);
	close(fd1);
	close(fd2);
//	printf("%c\n",argv[2][0]);

}
