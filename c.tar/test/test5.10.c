/*write a program which executes reverse polish expression in command line argument*/
#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#define MAX 100
void push(double);
double pop(void);
int stack[100];
int top=0;
int main(int argc,char **argv)
{

	int i;
	int n;
	double op2;
	//printf("give input in command line like 20 10 +");
	for(i=1;argv[i];i++)
	{
		if(isdigit(argv[i][0]))
		{
			n=atoi(argv[i]);
			stack[top++]=n;
		}
		else
		{
			switch(argv[i][0])
			{
			case '+':push(pop()+pop());
		       		break;
			case '*':push(pop()*pop());
				break;
			case '-':op2=pop();
				push(pop()-op2);
				break;
	       		case '/':op2=pop();
	 			if(op2!=0.0)
	       			push(pop()/op2);
 				else
					printf("error:zero divisor");
			case '%':op2=pop();
				if(op2!=0.0)
			       push((int)pop()%(int)op2);
		 		else
			       printf("error");
			}
		}
		
	}
	printf("%d",stack[0]);
}
void push(double  f)
{
	if(top<MAX)
	stack[top++]=f;
}
double  pop(void)
{
	if(top>-1)
	return	stack[--top];
}

       								
