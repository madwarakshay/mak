/** Write a function rightrot(x,n)
that returns the value of the
integer x rotated to the right by n bit positions. 0**/
#include<stdio.h>
void rightrot(int x,int n);
main()
{
	int i,p,n;
	printf("enter i val ;");
	scanf("%d",&i);
	printf("enter pos :");
	scanf("%d",&p);
	rightrot(i,p);
}
void rightrot(int x,int n)
{int j,i;
	printf("%x",(x>>n)|x<<(8-n));
}


