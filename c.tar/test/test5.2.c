/*getfloat function ,the floating point analog of getint. what type getfloat return as its function value*/
#include<stdio.h>
#include<string.h>
#include<ctype.h>
float getfloat(int *);
int  getch(void);
void ungetch(int );
float buf[100];
int bufp=0;
int main()
{
	int n;
	float array[20],r;
	for(n=0;n<20 && (r=getfloat(&array[n]))!=EOF;n++)
	{
		if(r)
		{
			printf("your input number %f\n",array[n]);
		}
		else
		{
			printf("not ano");
		}
	}

		return 0;
}
int  getfloat(float *p)
{
	int  c,c1;
	int sign;
	while(isspace(c=getch()))
		;
	if(!isdigit(c) && c!=EOF && c!='+' &&c!='-')
	{
		ungetch(c);
		return 0;
	}
	sign=(c=='-')?-1:1;
	if(c=='+' ||c=='-')
	{
		if(!isdigit(c1=getch()))
		{
			ungetch(c1);
			ungetch(c);
			return 0;
		}
		else
		{
			c=c1;
		}
	}
	for(*p=0.0;isdigit(c);c=getch())
	*p=10**p+(c-'0');
	if(c=='.')
		c=getch();
	for(power=1.0;isdigit(c);c=getch())
	{
		*p=10.0**p+(c-'0');
		power*=10.0;
	}
	epower=1;
	if(c
	*p*=sign;
	if(c!=EOF)
		ungetch(c);
	return(c);
}
int getch(void)
{
	return(bufp>0)?buf[--bufp]:getchar();
}
void ungetch(int c)
{
	if(bufp>=100)
		printf("ungetch: too many arguments\n");
	else
		buf[bufp++]=c;
}
	

