/*modify sort program to handle -r flag to sort in reverse order*/
#include<stdio.h>
#include <string.h>
#include<stdlib.h>
#define MAX 20
int  MAXLINES= 10;
char *lineptr[10];
int readlines(char *lineptr[], int nlines);
void writelines(char *lineptr[], int nlines);
void sort(char *lineptr[], int nlines );
int main(int argc, char *argv[])
{
int nlines;
if (argc > 1 && strcmp(argv[1], "-d") == 0)
if((nlines = readlines(lineptr, MAXLINES))>= 0)
{
sort(lineptr,nlines);
writelines(lineptr, nlines);
return 0;
}
else
{
printf("input too big to sort\n");
return 1;
}
}
void swap(void *v[],int i,int j)
{
	void *temp;
	temp=v[i];
	v[i]=v[j];
	v[j]=temp;

}
int ggetline(char *,int);
int readlines(char *lineptr[],int MAXLINES)
{
	int len,nlines;
	char *p,line[MAXLINES];
	nlines=0;
	while((len=ggetline(line,MAX))>1)
	{
			if(nlines>=MAXLINES ||(p=malloc(len))==NULL)
			return -1;
			else
			{
				line[len-1]=' ';
				strcpy(p,line);
				lineptr[nlines++]=p;
			}
	}
	return nlines;
}
void writelines(char *lineptr[],int nlines)
{
	int i;
	for(i=0;i<nlines;i++)
		printf("%s\n",lineptr[i]);
}

int ggetline(char s[],int lim)
{
	int c,i;
	for(i=0;i<lim-1 && (c=getchar())!=EOF&&c!='\n';i++)
		s[i]=c;
	if(c=='\n')
	{
		s[i++]=c;
	}
	s[i]='\0';
	return i;
}
void sort (char *lineptr[],int n)
{
int i,j,k;
char *temp,ch1,ch2;
/*for(i=0;i<n;i++)
{
	for(j=0;j<n;j++)
	{
		if(lineptr[i][j]>='A' && lineptr[i][j]<='Z')
			lineptr[i][j]+=32;
	}
}*/
for(i=0;i<n;i++)
{
	for(j=1;j<n;j++)
	{
		for(k=0;k<n;k++)
		{
			ch1=lineptr[i][k];
			ch2=lineptr[j][k];
			if((ch1>='0' && ch1<='9') && (ch2>='0' && ch2<='9'))
			if(ch1>ch2)
			{
			temp=lineptr[i];
			lineptr[i]=lineptr[j];
			lineptr[j]=temp;
			
			break;
			}
		}
	}
}
}

