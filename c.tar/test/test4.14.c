/*define macro swap that interchanges two arguments of type t*/
#include<stdio.h>
#include<string.h>
#define swap(type,x,y)  type temp;temp=x;	x=y;	y=temp;
int main()
{
	int i,j;
	printf("enter i val:");
	scanf("%d",&i);
	printf("enter j val:");
	scanf("%d",&j);
	printf("before i: %d  j: %d\n",i,j);
	swap(int,i,j);
	printf("after  i: %d  j: %d\n",i,j);
}


