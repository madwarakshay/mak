/***Write a program to remove all comments from a C program.
to remove brackets .Don't forget to handle quoted strings and character constants properly. C com-
ments do not nest.***/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(int argc,char **argv)
{
	int n=0,i;
	FILE *fp;
	char *s=NULL;
	fp=fopen(argv[1],"r");
	fseek(fp,0,2);
	n=ftell(fp);
	printf("size=%d",n);
	rewind(fp);
	s=realloc(s,(n+1)*1);
	for(i=0;i<n;i++)
	{
		s[i]=fgetc(fp);
	}
	//fread(s,sizeof(*s),1,fp);
	fclose(fp);
	

	
	for(i=0;s[i];i++)
	{
		if((s[i]=='/')&&(s[i+1]=='/'))
		{
			do
			{
				memmove(s+i,s+i+1,strlen(s+i+1)+1);
			}while(s[i]!='\n');
		}
		else if((s[i]=='/') && s[i+1]=='*')
		{
			do
			{
				memmove(s+i,s+i+1,strlen(s+i+1)+1);
			}while(!(s[i]=='*')&&s[i+1]=='/');

			memmove(s+i,s+i+2,strlen(s+i+2)+1);
		}
	}
	for(i=0;s[i];i++)
	{
		printf("%c",s[i]);
	}


}

		
