/***Write a program to copy its input to its output, replacing each
string of one or more blanks by a single blank. 0***/
#include<stdio.h>
int main()
{
	int c;
	while((c=getchar())!=EOF)
	{
		if(c==' ')
		{
			while((c=getchar())==' ')
			{
			}
			putchar(' ');
		}
		else
		{
			putchar(c);
		}
	}
}
			
