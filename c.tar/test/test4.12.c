/*adapt ideas of printt d to write recursion version of itoa*/
#include<stdio.h>
void printa(int ,char *);
int main()
{
	int n;
	char buf[20];
	printf("enter inter val:\n");
	scanf("%d\n",&n);
	printa(n,buf);
	printf("buf=%s\n",buf);
}
void printa(int n,char s[])
{
	static int i;
	if(n/10)
		printa(n/10,s);
	else
	{
	i=0;
	if(n<0)
		s[++i]='-';
	}
	s[i++]=abs(n)%10+'0';
	s[i]=' ';
}

