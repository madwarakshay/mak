#include<stdio.h>
#include<string.h>
void squeeze(char s[],char d[]);
main()
{
	char str3[20],str4[20];
//	int i,j;
	printf("enter string 1: ");
	scanf("%s",str3);
	printf("enter string 2: ");
	scanf("%s",str4);
	squeeze(str3,str4);
}
	void squeeze(char str1[],char str2[])
	{
		int i,j;
	for(i=0;str1[i];i++)
	{
		for(j=0;j<strlen(str2);j++)
		{
			if(str1[i]==str2[j])
			{
				memmove(str1+i,str1+i+1,strlen(str1+i+1)+1);
				--i;
				break;
				


			}
			
		}
		
	}
	printf("%s",str1);
	}

