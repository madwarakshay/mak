/*add library function like pow to the stack program*/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#define MAX 100
void push(double);
double pop(void);
int stack[100];
int top=0;
double po(double,int);
int main()
{

	int cnt=0,n,temp,power;
	char c;
//	double op2;
	printf("input should be like 12 34 56 44 =");
	while((c=getchar())!='=')
	{
		if((c>=48) &&( c<=57))
		{
			if(c==' ')
			{
				cnt=0;
			}
			if(cnt==0)
			{
			stack[top++]=c-48;
			cnt++;
			}
			else
			{
				top--;
				stack[top]=(stack[top]*10)+(c-48);
				top++;
			}
		}
		else if(c==' ')
			{
				cnt=0;
			}
	}
	printf("%d\n",stack[top-1]);
	while(1)
	{
		printf("1: for top of stack     2:for swap two elem \n3:for clear,4:sin 5:pow :\n");
		scanf("%d",&n);
		switch(n)
		{
			case 1:printf("%d\n",stack[--top]);
				 ++top;
				 break;
			case 2:
				 temp=stack[top-1];
				 stack[top-1]=stack[top-2];
				 stack[top-2]=temp;
				 
				 printf("after swap\n");
				 for(temp=0;temp<top;temp++)
		
			
					 printf("%d ",stack[temp]);
				 break;
			case 3: for(temp=top-1;temp>=0;temp--)
					stack[temp]=0;
				printf("%c",stack[temp]);
				break;
		/*	case 4:for(temp=top-1;temp>=0;temp--)
			       {
				       printf("%lf\n",sin(stack[temp]));
			       }
			       break;*/
			case 5:printf("enter power");
			       scanf("%d",&power);
			       for(temp=top-1;temp>=0;temp--)
				       printf("%lf\n",po(stack[temp],power));
			default:printf("*");
	}	}
}


void push(double  f)
{
	if(top<MAX)
	stack[top++]=f;
}
double  pop(void)
{
	if(top>= 0)
	{	
	return stack[--top];
	}
}

double po(double a,int b)
{
	int i;
	double k=1.0;
	for(i=0;i<b;i++)
		k=k*a;
	return k;
}

       								
