/*function escape converts characters like newline and tab into visible sequences*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
void escape(char a[],char b[]);
void rescape(char c[]);
main()
{
	int c;
	char  s[30],t[30];
	printf("enter choice");	
	scanf(" %d",&c);
	printf("enter string ;");
	__fpurge(stdin);
	scanf("%[^!]",t);
	printf("%s\n",t);
	switch(c)
	{
		case 1: escape(s,t);
			// break;
		case 2: rescape(s);
 			break;
	}
}
void escape(char s[],char t[])
{
	int i,j,k;
	for(i=0,j=0;t[i];i++,j++)
	{
		if(t[i]=='\n')
		{
			s[j++]='\\';
			s[j]='n';
		}
		else if(t[i]=='\t')
		{
			s[j++]='\\';
			s[j]='t';
		}
		else
			s[j]=t[i];
	}
	s[j]='\0';

	for(k=0;s[k];k++)
		putchar(s[k]);
 putchar('\n');
}
void rescape(char s[])
{
	int k;
	for(k=0;s[k];k++)
	if(s[k]=='\\')
	{
	
			if(s[++k]=='n')
				putchar('\n');
			else if (s[k]=='t')
				putchar('\t');
			else
			putchar(s[k]);
	}
	else
			putchar(s[k]);
 putchar('\n');
}
