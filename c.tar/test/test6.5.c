/*function undef that will remove a name and defination from lookup table and install*/
#include<stdio.h>
#include<string.h>
struct nlist
{
	struct nlist *next;
	char *name;
	char *def;
};
static struct nlist *hashtab[101];
unsigned hash(char *s)
{
	unsigned hashval;
	for(hashval=0;*s!='\0';s++)
		hashval=*s+31*hashval;
	return hashval%101;
}
struct nlist *lookup(char *s)
{
	struct nlist *np;
	for(np=hashtab[hash(s)];np!=NULL;np=np->next)
		if(strcmp(s,np->name)==0)
			return np;
	return NULL;
}
struct nlist *uninstall(char *name,char *def)
{
	struct nlist *np;
	if((np=lookup(name))!=NULL)
		np=np->next;
	else
		printf("name to be removed is not found\n");
}
struct nlist *install(char*name,char *def)
{
	struct nlist *np;
	unsigned hashval;
	if((np=lookup(name))==NULL)
	{
		np=(struct nlist *)malloc(sizeof(*np));
	if(np==NULL ||(np->name=strdup(name))==NULL)
		return NULL;
	hashval=hash(name);
	np->next=hashtab[hashval];
	hashtab[hashval]=np;
	}
else
free((void *)np->def);
if((np->def=strdup(def))==NULL)
	return NULL;
	return np;
	
}

int main()
{
	char name[20],def[20];
	printf("enter name\n");
	scanf("%s",name);
	printf("enter def\n");
	scanf("%s",def);
	install(name,def);
	uninstall(name,def);
}


