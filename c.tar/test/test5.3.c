/*strcat function copies string t to end of s*/
#include<stdio.h>
#include<string.h>
void strrcat(char *,char *);
int main()
{
	char s[20],t[20];
	printf("enter string s :\n");
	scanf("%s",s);
	printf("enter string t ;\n");
	scanf("%s",t);
	strrcat(s,t);
//	strcpy(s+strlen(s),t);
//	printf("%s",s);
}
void strrcat(char *s,char *t)
{
	int i,j;
	i=j=0;
	while(s[i]!='\0')
		i++;
	while((s[i++]=t[j++])!='\0')
		;
	printf("%s",s);
}
