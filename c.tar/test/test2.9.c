/*to find the bit of number*/
#include<stdio.h>
int bitcount(unsigned int);
int main()
{
	int n,i;
	printf("enter n val\n");
	scanf("%d\n",&n);
	i=bitcount(n);
	printf("%d\n",i);
}
int bitcount(unsigned int a)
{
	int b;
	for(b=0;a!=0;a&=a-1)
		++b;
	return b;
}

