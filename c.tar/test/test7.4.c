/*write private version of scanf*/
#include<stdio.h>
#include<stdarg.h>
void minscanf(char *fmt,...)
{
	va_list ap;
	char *p,*sval;
	int *ival;
	float *fval;
	va_start(ap,fmt);
		for(p=fmt;*p;p++)
		{
			if(*p=='%')
			{
			switch(*++p)
			{
				case 'd':
					ival=va_arg(ap,int *);
					scanf("%d",ival);
				
				//	printf("%d",ival);
					 break;
				case 'f':
					 fval=va_arg(ap,double *);
					 scanf("%f",fval);
					 //printf("%f",fval);
					 break;
				case 's':
				 sval=va_arg(ap,char *);
				 scanf("%s",sval);
					// putchar(*sval);
				 break;
				default:putchar(*p);
					break;
			}
			}
			else if(*p=='\\')
			{
				switch(*++p)
				{
					case 'n':putchar('\n');
						 break;
					case 't':putchar('\t');
						 break;
					case 'b':putchar('\b');
						 break;
					default:putchar(*p);
						break;
				}
			}
			else
			{
				putchar(*p);
			}
		}
	va_end(ap);
}
int main()
{
	char c='a';
	int i;
	minscanf("%d\n",&i);
	printf("%d",i);
}
