#include<stdio.h>
main()
{
	int c;
	while((c=getchar())!='\n')
	{
		if(!(c==' '||c=='\n'||c=='\t'))
			putchar('*');
		else
			putchar('\n');
	}
}
