/*in two's complement number representation itoa does not handle largest numbers modify to print correctb val*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
void itoa(int n,char s[]);
void reverse(char s[]);
main()
{
	char s[20];
	 int n;
	printf("enter n;");
	scanf("%d",&n);
//	n=~n;
//	n+=1;
	itoa(n,s);
}
void itoa( int n,char s[])
{
	unsigned int k;
	int i=0,sign;
	k=n;
	if((sign=k)<0)
		k=-k;
	do
	{
		s[i++]=k%10+'0';
	}while((k/=10)>0);
	if(sign<0)
		s[i++]='-';
	s[i]='\0';
	reverse(s);
	puts(s);
}
void reverse(char s[])
{
	char temp;
	int l,m;
	for(l=0,m=strlen(s)-1;m>l;l++,m--)
	{
		temp=s[l];
		s[l]=s[m];
		s[m]=temp;
	}
	puts(s);
}


