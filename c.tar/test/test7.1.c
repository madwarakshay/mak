/*program that convert uppercase to lower case*/
#include<stdio.h>
#include<ctype.h>
main(int argc,char **argv)
{
	int i;
       		char c[20];
	
		for(i=0;argv[1][i];i++)
		{
		if(argv[1][i]>='A'&& argv[1][i]<='Z')
		
			putchar(tolower(argv[1][i]));
		
		else if(argv[1][i]>='a' && argv[1][i]<='z')
		
			putchar(toupper(argv[1][i]));
		
		else
		putchar(argv[1][i]);
		}
}

