/***Write a program to copy its input to its output, replacing each
tab by \ t, each backspace by \b, and each backslash by \ \. This makes tabs
and backspaces visible in an unambiguous way. 0***/
#include<stdio.h>
int main()
{
		int c;
		printf("enter input with = at the end \n");
		while((c=getchar())!='=')
		{
			if(c=='\t')
			{
			printf("\\t");
			}
			else if(c=='\b')
			{
				printf("\\b");
			}
			else
			{
				putchar(c);
			}
		}
}
