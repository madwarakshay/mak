/*** Write a program to print the value of EOF. 0***/
#include<stdio.h>
int main()
{
	int c;
	c=getchar();
	while(c!=EOF)
	{
		putchar(c);
		printf("%d",EOF);
		c=getchar();
	}
}
