/*routine ungets that will push back entire string into input*/
#include<stdio.h>
char *getch(void);
void ungetch(char*);
char buf[100]=0;
main()
{
	char a[100];
	a=getch();
	printf("in a:   %s\n",a);
	ungetch(a);
	printf("in buf:  %s",buf);
}
char *getch(void)
{
	char c[100];
	if(buf!=0)
	{
		for(int i=0;i<strlen(buf)-1;i++)
		c[i]=buf[i];
	}
	else
	{
		gets(c);
	}
	return *c;
}
void ungetch(char *c)
{
	
	if(buf==0)
	{
		printf("buf is full");
	}
	else
	{
	for(int i=0;buf[i],c[i];i++)
	{
		buf[i]=c[i];
	}
	}

}

