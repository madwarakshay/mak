/***Write a program to print the corresponding Celsius to Fahrenheit
table. 0***/
#include<stdio.h>
int main()
{
	float cel,farn;
	int low,high,step;
	low=0,high=100,step=20;
	printf("temperature    farenheit\n");
	cel=0;
	while(cel<=100)
	{
		farn=(9.0/5.0)*cel+32.0;
		printf("%3.0f %14.1f\n",cel,farn);
		cel+=step;
	}
}
