/*program tail which prints n lines from bottom*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(int argc,char **argv)
{

	int i,k,l,j,cnt=0;
	char str[10][20],linebuf[20];
	printf("enter input\n");
	FILE *fp;
	fp=fopen(argv[1],"r");
	j=0;
	while(fgets(linebuf,20,fp))
	{
		strncpy(str[j],linebuf,20);
		puts(str[j]);
		j++;
	}

	i=atoi(argv[2]);
	printf("%d\n",i);
	if(i<0)
		i=-i;
	k=j-i;
	printf("%d\n",k);
	while(k<=10)
	{
		puts(str[k]);
		k++;
	}
}

