/*program that print non graphical characters in octal */
#include<stdio.h>
#include<ctype.h>
main()
{
	int c,i=0;
	while((c=getchar())!=EOF)
	{
		i++;
		if(i>20)
			printf("\n");
		if(c=='\\')
		{
			if((c=getchar())=='n'||'b')
			{
			printf("%o",c);
		}
		}
		else
		{
			putchar(c);
		}
	}
}


