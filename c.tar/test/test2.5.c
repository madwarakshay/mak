/***Write the function any (s 1, s2 ), which returns the first location
in the string s 1 where any character from the string s2 occurs, or -1 if s 1
contains no characters from s2. (The standard library function strpbrk does
the same job but returns a pointer to the location.) 0***/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
char *any(char s6[],char s7[]);
main()
{
	char  *k;
	char s1[20],s2[20];
	printf("enter s1 ; ");
	scanf("%s",s1);
	printf("enter s2 ; ");
	scanf("%s",s2);
		if((k=any(s1,s2))>0)
		{
			printf("location=%d",k);
		}

}
char *any(char a[],char b[])
{

	int i,j;
	for(i=0;a[i];i++)
	
		for(j=0;j<strlen(b);j++)
		
			if(a[i]==b[j])
			
				return &a[i];
			
			
			
				return -1;
			
		
	
	
}


