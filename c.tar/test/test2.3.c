/*function htos converts string of hexadecimal to integer*/
#include<stdio.h>
int htoi(char s[])
{
	int hexdig,inhex,n,i=0;
	if(s[i]=='0')
	{
		++i;
		if(s[i]=='x' ||'X')
			++i;
	}
	n=0;
	inhex=1;
	for(;inhex==1;++i)
	{
		if(s[i]>='0' && s[i]<='9')
			hexdig=s[i]-'0';
		else if(s[i]='a' && s[i]<='f')
			hexdig=s[i]-'a'+10;
		else if(s[i]>='A' && s[i]<='F')
			hexdig=s[i]-'A'+10;
		else
			inhex=0;
				if(inhex==1)
					n=16*n+hexdig;
	}

	printf("%d\n",n);
	return n;
}
int main()
{
	char str[20];
	printf("enter hex no\n");
	scanf("%s\n",str);
	htoi(str);
	//printf("%d\n",n);
}
