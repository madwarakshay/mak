/*extend atof to handle scientific notation of the form*/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<ctype.h>
double myatof(char s[]);
double po(double a,int b);
int main()
{
	char str[100];
	double p;
	puts("enter float val :");
	printf("$");
	scanf("%[^@]",str);
	p=myatof(str);
	printf("%lf",p);
}
double myatof(char s[])
{
	double n=0;
	int i,cnt=1;
	for(i=0;isdigit(s[i]);i++)
	{
		n=n*10+(s[i]-48);
	}
	if(s[i]=='.')
		i++;

	for(i;isdigit(s[i]);i++)
	{
		cnt=cnt*10;
		n=n*10+(s[i]-48);
	}
	n/=cnt;
	if((s[i]=='e')||(s[i]=='E'))
	{
		if(s[++i]=='-')
		{
			++i;
			int c=0,d;
		for(i;isdigit(s[i]);i++)
			c=c*10+(s[i]-48);
		n/=(po(10,c));
	
		}
		else if(s[i]=='+')
		{
			++i;
			int c=0;
			for(i;isdigit(s[i]);i++)
				c=c*10+(s[i]-48);
	
		n*=(po(10,c));
		}
	}
	return n;
	
}
double po(double n,int k)
{
	int i;
	double m=1.0;
	for(i=0;i<k;i++)
		m=m*n;
	return m;
}

