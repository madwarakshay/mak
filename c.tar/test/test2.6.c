/** Write a function setbits(x,p,n,y)
that returns x with the n
bits that begin at position p set to the rightmost n bits of y, leaving the other
bits unchanged. 0***/
#include<stdio.h>
void setbits(int, int,int,int); 
main()
{
	int i,p,n,y;
	printf("enter i value :");
	scanf("%d",&i);
	printf("enter pos value :");
	scanf("%d",&p);
	printf("enter no of bits :");
	scanf("%d",&n);
	printf("enter  y val ");
	scanf("%d",&y);

	setbits(i,p,n,y);
}
void setbits(int i,int p,int n,int y)
{
	int k,z;
	k=((i>>(p+1-n)) & ~(~0<<n));
	y=~y;
	z=k&y;
	printf("%d\n",k);
	for(i=31;i>=0;i--)
	printf("%d",(z>>i)&1);
}
