/*modify the pattern program to take input from set of named files*/
#include<stdio.h>
#include<string.h>
//char *fgets(char *,int ,FILE *);
int main(int argc,char **argv)
{
	char s1[30],s2[30];
	int n=30;
	FILE *fp1,*fp2;
	fp1=fopen(argv[1],"r");
	fp2=fopen(argv[2],"r");
	while(fgets(s1,n,fp1) && fgets(s2,n,fp2))
	{
		if(strcmp(s1,s2)==0)
		{
		printf("%s\n %s\n",argv[1],argv[2]);
		break;
		}
	}
}/*
char *fgets(char *s,int n,FILE *iop)
{
	 int c;
	static  char *cs;
	cs=s;
	while(--n>0 && (c=getc(iop)!=EOF))
			if((*cs++=c)=='\n')
			break;
			*cs='\0';
			return(c==EOF && cs==s)?NULL:s;
			return cs;
}*/

