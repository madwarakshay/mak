/***How would you test the word count program? What kinds of
input are most likely to uncover bugs if there are any? 0***/
#include<stdio.h>
int main()
{
	int c;
	while((c=getchar())!=EOF)
	{
		if((c==' ')||(c=='\t')||(c=='\n'))
				{
				putchar('\n');
				}
				putchar(c);
	}
}

