#define NULL 0
#define EOF (-1)
#define BUFSIZ 1024
#define OPEN_MAX 20
typedef struct _iobuf
{
	int cnt;
	char *ptr;
	char *base;
	int flag;
	int fd;
}FILE;
FILE iob[OPEN_MAX]={
	{0,(char *)0,(char *)0,01,0},
	{0,(char *)0,(char *)0,02,1},
	{0,(char *)0,(char *)0,02|04,2}
};
#define stdin (&iob[0])
#define stdout (&iob[1])
#define stderr (&iob[2])


