/*modify entab detab program to accept list of tab stops as arguments*/
#include<stdio.h>
#include<string.h>
int main(int argc,char **argv)
{
	int i;
	for(i=1;argv[i];i++)
	{
		if(argv[i][0]=='\\')
		{
			switch(argv[i][1])
			{
				case 't': printf("\\");
					 break;
				case 'n':putchar('\n');
					 break;

			}
		}
		else
		{
			printf("%s",argv[i]);
		}
	}
}


