/*userdefined strncpy program */
#include<stdio.h>
#include<string.h>
void sstrncpy(char *,char *,int);
int main()
{
	int n;
	char s[20],t[20];
	printf("enter t string :\n");
	scanf("%s",t);
	printf("enter no of characters to be copied\n");
	scanf("%d",&n);
	sstrncpy(s,t,n);
}
void sstrncpy(char *s,char *t,int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		s[i]=t[i];
	}
	printf("%s",s);
}
