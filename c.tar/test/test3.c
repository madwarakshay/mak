#include<stdio.h>
#define MAX 10
#define SIZE 10
int main()
{
	int c,words=0,letters=0;
	int arr[MAX];
	for(int i=0;i<MAX;i++)
		arr[i]=0;
	printf("enter name");
	while((c=getchar())!=EOF)
	{
		if(!(c==' '||c=='\n'||c=='\t'))
		{	
		arr[words]++;
		}
		else
		{
			words++;
		}
	}
	printf("%d",words);
/*	for(int i=SIZE;i>=0;i--)
	{
		printf("\n");
		for(int j=0;j<=MAX;j++)
		{
			if(arr[j]>=i)
				printf("*");
			else
				printf(" ");
		}
	}*/
}

