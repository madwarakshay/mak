#include<stdio.h>
#define MAXLINE 1000
int ggetline(char line[],int maxline);
int main()
{
	char line[MAXLINE];
	int max=10,len;
	
	while((len=ggetline(line,MAXLINE))>0)
	{
		if(len>max)
		{
			printf("%s",line);
		}
		else
			break;
	}
}
int ggetline(char s[],int n)
{
	int c,i;
	for(i=0;i<n-1 && (c=getchar())!=EOF && c!='\n';++i)
	
		s[i]=c;
		if(c=='\n')
		{
			s[i]=c;
			++i;
		}
		s[i]='\0';
		
	
	return i;
}

