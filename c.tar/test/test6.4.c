/*program that prints distinct words in its input into decreasing order of freq of occurance*/
#include<stdio.h>
#include<string.h>
int main()
{
	char word[4][7],word1[4][7];
	int i,j,cnt[4];
	for(i=0;i<4;i++)
	{
		cnt[i]=0;
		scanf("%s",word[0]);
	}
	strcpy(word1[0],word[0]);
	printf("%s",word1[0]);
	for(i=0;i<4;i++)
	{
		for(j=1;j<4;j++)
		{
			//printf("*");
			if(strcmp(word[i],word[j])==0)
			{
				printf("*");
				cnt[++i];
			}
			else
			{
				strcpy(word1[j],word[j]);
				printf("%s",word1[j]);
				cnt[++j];
			}
		}
	}
	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
		
		if(i==cnt[j])
			
		printf("%d %s\n",cnt[j],word1[j]);
	
		}
	}

	


}
