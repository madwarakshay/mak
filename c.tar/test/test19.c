/*** Write a function reverse (s) that reverses the character
string s. Use it to write a program that reverses its input a line at a time. 0***/
#include<stdio.h>
#include<string.h>
#define MAXLINE 1000
int ggetline(char line[],int maxline);
void reverse(char s1[]);
int main()
{
	char line[MAXLINE],revline[MAXLINE];
	int max=10,len;
	
	while((len=ggetline(line,MAXLINE))>0)
	{
		reverse(line);

			printf("%s",line);
		
		
	}
}
int ggetline(char s[],int n)
{
	int c,i;
	for(i=0;i<n-1 && (c=getchar())!=EOF && c!='\n';++i)
	
		s[i]=c;
		if(c=='\n')
		{
			s[i]=c;
			++i;
		}
		s[i]='\0';
		
	
	return i;
}
void reverse(char *s1)
{
	char temp;
	int j;
	for (int i=0,j=strlen(s1)-1;i<j;i++,j--)
	{
		temp=s1[i];
		s1[i]=s1[j];
		s1[j]=temp;
	}
	printf("%s",s1) ;
}

