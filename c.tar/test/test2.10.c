/*function lower which converts upper case to lower case*/
#include<stdio.h>
#include<string.h>
main()
{
	char c,s[250];
	int i=0,j;
	while((c=getchar())!='\n')
	{
		
		s[i]=c;
		i++;
	}
//		printf("%s",s);
		for(j=0;s[j];j++)
	{
		s[j]=(s[j]>='A'&& s[j]<='Z')?(s[j]+32):s[j];
		printf("%c",s[j]);
	}
}
