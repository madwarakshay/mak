/*function expand that expands notations like a-z in string 1 to abc...xyz in string 2*/
#include<stdio.h>
#include<string.h>
//void expand(char s1[],char s2[]);
main()
{	int k,n=0,m=0,i,j;
	char s[20],t[40];
	printf("enter sstring:" );
	scanf("%[^.]",s);
	for(i=0,j=0;s[i];i++,j++)
	{
		
		if((s[i]=='a') && (s[i+1]=='-') && (s[i+2]=='z'))
		{
		for(k=0;k<26;k++)
		{
		putchar(65+n);
		n++;
		}
		i=i+2;
		}
		else if(s[i]=='0' && s[i+1]=='-' && s[i+2]=='9')
		{
			for(int l=0;l<10;l++)
			{
				putchar(48+m);
				m++;
			}
				i=i+2;
			
		}
		else
		{
		t[j]=s[i];
		putchar(s[i]);
		}
	}	
	s[i]='\0';

}	
		


