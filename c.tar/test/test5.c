#include<stdio.h>
void celtofarn(int,int);
int main()
{
	int high,step;
	printf("enter max temp\n");
	scanf("%d",&high);
	printf("enter step size");
	scanf("%d",&step);
	celtofarn(high,step);
}
	void celtofarn(int n,int s)
	{
		float cel,farn;
		for(cel=0;cel<=n;cel+=s)
		{
			printf("%3f %14.1f\n",cel,9.0/5.0*cel+32.0);
		}
		
	}

