/*alternate organisation uses getline to read entire input line makes getch and ungetch unnecessary revise calculator to use this approach*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAX 100
void push(double);
double pop(void);
char *getlinee(void);
int stack[100];
int top=0;
int main()
{

	int cnt=0,i;
	char *c;
	double op2;
	c=getlinee();
		for(i=0;i<strlen(c);i++)
		{
		if((c[i]>=48) &&( c[i]<=57))
		{
			if(cnt==0)
			{
			stack[top++]=c[i]-48;
			cnt++;
			}
			else
			{
				top--;
				stack[top]=(stack[top]*10)+(c[i]-48);
				top++;
			}
		}
		else
		{
			switch(c[i])
			{
			case ' ':cnt=0;
				 break;
			case '+':push(pop()+pop());
		       		break;
			case '*':push(pop()*pop());
				break;
			case '-':op2=pop();
				push(pop()-op2);
				break;
	       		case '/':op2=pop();
	 			if(op2!=0.0)
	       			push(pop()/op2);
 				else
					printf("error:zero divisor");
			case '%':op2=pop();
				if(op2!=0.0)
			       push((int)pop()%(int)op2);
		 		else
			       printf("error");
			}
		}
		}
	
	printf("%d",stack[0]);
}
void push(double  f)
{
	if(top<MAX)
	stack[top++]=f;
}
double  pop(void)
{
	if(top>-1)
	return	stack[--top];
}
char * getlinee(void)
{
	static char c[40];
	int i=0;
	while((c[i]=getchar())!='\n')
		i++;
	return c;
}
       								
