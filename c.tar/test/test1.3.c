/***Exercise 1-3. Modify the temperature
above the table. 0
conversion program to print a heading***/
#include<stdio.h>
int main()
{
	float cel,farn;
	int step=20;
	printf("temperature    farenheit\n");
	cel=0;
	while(cel<=100)
	{
		farn=(9.0/5.0)*cel+32.0;
		printf("%3.0f %14.1f\n",cel,farn);
		cel+=step;
	}
}
