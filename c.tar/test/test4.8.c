/*modify getch and ungetch that there is no more then one character*/
#include<stdio.h>
char getch(void);
void ungetch(char);
char buf=0;
main()
{
	char a;
	a=getch();
	printf("in a:   %c\n",a);
	ungetch(a);
	printf("in buf:  %c",buf);
}
char getch(void)
{
	char c;
	if(buf!=0)
	{
		c=buf;
	}
	else
	{
		c=getchar();
	}
	return c;
}
void ungetch(char c)
{
	if(buf!=0)
	{
		printf("buf is full");
	}
	else
	{
		buf=c;
	}
}

