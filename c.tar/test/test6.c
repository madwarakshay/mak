#include<stdio.h>
main()
{
	char c;
	int arr[256];
	for(int i=0;i<256;i++)
		arr[i]=0;
	while((c=getchar())!='\n')
	{
	if(c>0&&c<=256)
	{
		++arr[c];
	}
	}
	for(int i=0;i<256;i++)
	{
	if(arr[i]>0)
	{
		printf("\n%c : ",i);
		for(int j=0;j<arr[i];j++)
		{
			printf("* ");
		}
	}
	}
}
