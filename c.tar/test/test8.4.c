/*standard lib function fseek*/
//#include<stdio.h>
#include"syscalls.h"
#include<stdlib.h>
#include<sys/file.h>
#include<fcntl.h>
#include<string.h>
#define PERMS 0666
FILE *ffopen(char *name,char *mode)
{
	int fd;
	char buf[100];
	FILE *fp;
	if(*mode!='r' && *mode!='w' && *mode!='a')
	return NULL;
	for(fp=iob;fp<iob+OPEN_MAX;fp++)
		if((fp->flag &(01|02))==0)
			break;
	if(fp>=iob+OPEN_MAX)
		return NULL;
	if(*mode=='w')
	{
		fd=creat(name,PERMS);
		puts("enter data\n");
		gets(buf);
		write(fd,buf,strlen(buf));
		fp->ptr=buf;
		fp->base=buf;
		puts(fp->ptr);
	}
	else if(*mode=='a')
	{
		if((fd=open(name,O_WRONLY,0))==-1)
			fd=creat(name,PERMS);
		lseek(fd,0L,2);
		puts("enter data\n");
		gets(buf);
		write(fd,buf,strlen(buf));
		lseek(fd,0L,0);
	}
	else
		fd=open(name,O_RDONLY,0);
	if(fd==-1)
		return NULL;
	fp->fd=fd;
	fp->cnt=0;
	//fp->base=;
	fp->flag=(*mode=='r')?01:02;
	return fp;
}
int _fffillbuf(FILE *fp)
{
	int bufsize;
	if((fp->flag&(01|010|020))!=01)
		return EOF;
	bufsize=(fp->flag & 04)?1:BUFSIZ;
	if(fp->base=NULL)
		if((fp->base=(char *)malloc(bufsize))==NULL)
			return EOF;
	fp->ptr=fp->base;
	fp->cnt=read(fp->fd,fp->ptr,bufsize);
	if(--fp->cnt<0)
	{
		if(fp->cnt==-1)
			fp->flag|=010;
		else
			fp->flag|=020;
		fp->cnt=0;
		return EOF;
	}
	return(unsigned char)*fp->ptr++;
}
void ffflush(char *name)
{
	
	creat(name,PERMS);

}
int ffseek(FILE *fp,long offset,int origin)
{
//	FILE *fq;
	if(offset==0 && origin==0)
	{
		fp->ptr=fp->base;
		return 1;
	}
	else if(offset==0 && origin==2)
	{
		while(*(fp->ptr)!=EOF)
		{
			fp->ptr++;
		}
		return 1;
	}
	else if(offset>0 && origin==0)
	{
		fp->ptr=fp->ptr+offset;
		return 1;
	}
	return -1;
}
int ffclose(FILE *fp)
{
	fp=NULL;
}



int main()
{
	char buff[40];
	FILE *fp;
	//_fillbuf(fp);
	//fputs(fp->ptr);
	fp=ffopen("file2","w");
//	fp->cnt=read(fp->fd,buff,400);

//	puts(buff);
//	fp->base=buff;
//	putc();
	puts(fp->base);
//	ffflush("file2");
//	puts(fp->base);
//	ffclose(fp);
	int i=ffseek(fp,0,2);
	if(i==1)
	puts("success");

	
}

