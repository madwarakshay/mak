/*** Modify the temperature conversion program to print the table in
reverse order, that is, from 300 degrees to O. 0**/
#include<stdio.h>
int main()
{
	float cel;
	int step=20;
	printf("temperature   farenheit\n");
	for(cel=0;cel>=300;cel+=step)
	{
		printf("%3.0f %14.1f\n",cel,(9.0/5.0)*cel+32.0);
	}
}
