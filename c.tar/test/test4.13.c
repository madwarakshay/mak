/*recursion function reverse(s) which reverses string*/
#include<stdio.h>
#include<string.h>
void reverse(char []);
void reverse_r(char [],int, int);
int main()
{
	int cnt=0;
	char s[20];
	printf("enter string\n");
	scanf("%s",s);
	reverse(s);
	printf("reverse: %s\n",s);
}
void reverse(char s[])
{
	reverse_r(s,0,strlen(s)-1);
}
void reverse_r(char s[],int i,int j)
{
		int temp;
		temp=s[i];
		s[i]=s[j];
		s[j]=temp;
		if(i<j)
			reverse_r(s,++i,--j);
}

