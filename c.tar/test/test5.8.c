/*error checking in day of year and month of day*/
#include<stdio.h>
void month_day(int ,int,int *,int *);
int dayofyear(int, int, int);
static int daytab[2][13]={
{0,31,28,31,30,31,30,31,31,30,31,30,31},
{0,31,29,31,30,31,30,31,31,30,31,30,31}
};
int main()
{
	int year,month;
	int day;
	printf("enter year month and dayof month\n");
	scanf("%d",&year);
	scanf("%d",&month);
	scanf("%d",&day);
	int c=dayofyear(year,month,day);
	printf("%d",c);

}
int dayofyear(int year,int month,int day)
{
	int i,leap,dayy=0;
	leap=year%4==0 && year%100!=0 || year%400==0;
	if(month>12)
	{
		printf("error invalid month\n");
		return 0;
	}
	for(i=1;i<month;i++)
		day+=daytab[leap][i];
	return day;
}
void month_day(int year,int yearday,int *pmonth,int *pday)
{
	int i,leap;
	leap=year%4==0 && year%100!=0||year%400==0;
	for(i=1;yearday>daytab[leap][i];i++)
		yearday-=daytab[leap][i];
	*pmonth=i;
	*pday=yearday;
}
