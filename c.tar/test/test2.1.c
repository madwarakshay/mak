/***Write a program to determine the ranges of char, short,
int,***/
#include<stdio.h>
int main()
{
	char c;
	short int a;
	int b;
	signed int d;
	printf("%ld  %ld %ld %ld",sizeof(c),sizeof(a),sizeof(b),sizeof(d));
	printf("%ld\n",pow(2,8*sizeof(c)));
	printf("%ld",pow(2,8*sizeof(b)));
	printf("%ld",pow(2,8*sizeof(d)));

}
