/*extend entab and detab to accept entab -m+n*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(int argc,char **argv)
{
	int i,n,j,k;
	char *buf=NULL;
	FILE *fp;
	fp=fopen(argv[1],"r");
	fseek(fp,0,2);
	n=ftell(fp);
	rewind(fp);
	buf=calloc(1,n+1);
	for(i=0;i<n;i++)
	{
		buf[i]=fgetc(fp);
		putchar(buf[i]);
	}
	fclose(fp);

	i=atoi(argv[3]);
	j=atoi(argv[4]);
	if(argv[2]=="entab")
		for(k=0;buf[k];k++)
		{
			if(k=i)
			{

			putchar('\t');
		}
}



