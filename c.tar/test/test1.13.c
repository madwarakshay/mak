/*** Write a program to print a histogram of the lengths of words in
its input. It is easy to draw the histogram with the bars horizontal; a vertical
orientation is more challenging. 0***/
#include<stdio.h>
#include<string.h>
int main()
{
	int i,j;
	i=0,j=0;
	char str[3][20];
	printf("enter sur name\n");
	gets(str[0]);
	printf("enter name\n");
	gets(str[1]);
	printf("enter last name\n");
	gets(str[2]);
	for(i=0;i<3;i++)
	{
		printf("\n");
		for(j=strlen(str[i]);j>0;j--)
		{
			printf("*");
		}
	}
}
