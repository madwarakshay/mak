/*rewrite atoi function by using pointers*/
#include<stdio.h>
#include<string.h>
int myatoi(char *);
int main()
{
	int p;
	char str[20];
	printf("enter value\n");
	scanf("%s",str);
	p=myatoi(str);
	printf("%d",p);
}
int myatoi(char *s)
{
	int i,n=0;
	for(i=0;s[i];i++)
	{
		n=n*10+(s[i]-48);
	}
	return n;
}


