/*function strend which returns 1 if the string t occurs at the end of string s*/
#include<stdio.h>
#include<string.h>
int strend(s,t);
int main()
{
	int i;
	char s[20],t[20];
	printf("enter strings :");
	scanf("%s",s);
	printf("enter string t ");
	scanf("%s",t);
	i=strend(s,t);
	if(i==1)
		printf("t occurs at end of string\n");
	else
		printf("t not occurs at end\n");

}
int strend(char *s,char *t)
{
	int i,j;
	i=j=0;
	while(s[i]!=t[j])
		i++;
	while((s[i++]==t[j++])!='\0')
		;
		if(t[j]=='\0')
			return 1;
		else
			return 0;
}
