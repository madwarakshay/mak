/*modify sort program to handle -r flag to sort in reverse order*/
#include<stdio.h>
#include <string.h>
#include<stdlib.h>
int  MAXLINES= 500;
char *lineptr[500];
int readlines(char *lineptr[], int nlines);
void writelines(char *lineptr[], int nlines);
void sort(char *lineptr[], int );
int main(int argc, char *argv[])
{
int nlines;
if (argc > 1 && strcmp(argv[1], "-r") == 0)
if((nlines = readlines(lineptr, MAXLINES))>= 0)
{
sort(lineptr,nlines);
writelines(lineptr, nlines);
return 0;
}
else
{
printf("input too big to sort\n");
return 1;
}
}
void swap(void *v[],int i,int j)
{
	void *temp;
	temp=v[i];
	v[i]=v[j];
	v[j]=temp;

}
int ggetline(char *,int);
int readlines(char *lineptr[],int MAXLINES)
{
	int len,nlines;
	char *p,line[MAXLINES];
	nlines=0;
	while((len=ggetline(line,MAXLINES))>1)
			if(nlines>=MAXLINES ||(p=malloc(len))==NULL)
			return -1;
			else
			{
				line[len-1]=' ';
				strcpy(p,line);
				lineptr[nlines++]=p;
			}
	return nlines;
}
void writelines(char *lineptr[],int nlines)
{
	int i;
	for(i=0;i<nlines;i++)
		printf("%s\n",lineptr[i]);
}

int ggetline(char s[],int lim)
{
	int c,i;
	for(i=0;i<lim-1 && (c=getchar())!=EOF&&c!='\n';i++)
		s[i]=c;
	if(c=='\n')
	{
		s[i++]=c;
	}
	s[i]='\0';
	return i;
}
void sort (char *lineptr[],int n)
{
int i,j;
char *temp;
for(i=0;i<n;i++)
{
	for(j=1;j<n;j++)
	{
		if(strcmp(lineptr[i],lineptr[j])>0)
		{
			temp=lineptr[i];
			lineptr[i]=lineptr[j];
			lineptr[j]=temp;
		}
	}
}
}
