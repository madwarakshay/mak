/***Write a program to "fold" long input lines into two or more
shorter lines after the last non-blank character that occurs before the n-th
column of input. Make sure your program does something intelligent with very
long lines, and if there are no blanks or tabs before the specified column.***/
#include<stdio.h>
int main()
{
	char s[15][30];
	int c,i=0,j=0,k,l,a=0;
	while(c=getchar())
	{
	if(c=='\n')
	{
		++i;
		break;
//		printf("*");
	}
	else
	{
		s[i][j]=c;	
		j++;
	}
	}
	for(k=0;k<i;k++)
	{
//	       printf("*");	
	
		for(l=0;l<=10,a<j;l++)
		{
			if(l==10)
			{
				
				putchar('\n');
				l=-1;
			}
			else
			{
			putchar(s[k][a]);
			a++;
			}
		}
	}
}


