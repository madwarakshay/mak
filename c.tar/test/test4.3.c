/*add modulus operator to the stack program*/
#include<stdio.h>
#include<stdlib.h>
#define MAX 100
void push(double);
double pop(void);
int stack[100];
int top=0;
int main()
{

	int cnt=0;
	char c;
	double op2;
	while((c=getchar())!='=')
	{
		if((c>=48) &&( c<=57))
		{
			if(cnt==0)
			{
			stack[top++]=c-48;
			cnt++;
			}
			else
			{
				top--;
				stack[top]=(stack[top]*10)+(c-48);
				top++;
			}
		}
		else
		{
			switch(c)
			{
			case ' ':cnt=0;
				 break;
			case '+':push(pop()+pop());
		       		break;
			case '*':push(pop()*pop());
				break;
			case '-':op2=pop();
				push(pop()-op2);
				break;
	       		case '/':op2=pop();
	 			if(op2!=0.0)
	       			push(pop()/op2);
 				else
					printf("error:zero divisor");
			case '%':op2=pop();
				if(op2!=0.0)
			       push((int)pop()%(int)op2);
		 		else
			       printf("error");
			}
		}
	}
	printf("%d",stack[0]);
}
void push(double  f)
{
	if(top<MAX)
	stack[top++]=f;
}
double  pop(void)
{
	if(top>-1)
	return	stack[--top];
}

       								
