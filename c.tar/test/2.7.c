#include<stdio.h>
void invert(int x,int p,int n);
main()
{
	int i,p,n;
	printf("enter i val ;");
	scanf("%d",&i);
	printf("enter pos :");
	scanf("%d",&p);
	printf("enter no of dig : ");
	scanf("%d",&n);
	invert(i,p,n);
}
void invert(int x,int p,int n)
{
	int j,i;
	for(i=p;i>p-n;i--)
		x=x^(1<<i);
	for(j=31;j>=0;j--)
		printf("%d",(x>>j)&1);
}


