/***Experiment to find out what happens when printf's
string contains \c, where c is some character not listed above. 0
argument***/
#include<stdio.h>
int main()
{
	printf("hello world\c");
}
