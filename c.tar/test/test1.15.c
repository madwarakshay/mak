/***Rewrite the temperature conversion program of Section 1.2 to
use a function for conversion.**/
#include<stdio.h>
void celtofarn(int, int);
main()
{
	int high,step;
	printf("enter max temp");
	scanf("%d\n",&high);
	printf("enter step size\n");
	scanf("%d",&step);
	celtofarn(high,step);
}
void celtofarn(int n,int s)
{
	int cel,farn;
	for(cel=0;cel<=n;cel+=s)
	{
		printf("%5d %14.1f\n",cel,9.0/5.0*cel+32.0);
	}
}
