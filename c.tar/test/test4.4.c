/*command to print the top element of stack*/
#include<stdio.h>
#include<stdlib.h>
#define MAX 100
void push(double);
double pop(void);
int stack[100];
int top=0;
int main()
{

	int cnt=0,n,temp;
	char c;
	double op2;
	while((c=getchar())!='=')
	{
		if((c>=48) &&( c<=57))
		{
			if(cnt==0)
			{
			stack[top++]=c-48;
			cnt++;
			}
			else
			{
				top--;
				stack[top]=(stack[top]*10)+(c-48);
				top++;
			}
		}
		else
		{
			push(c);
		}
	}
	while(1)
	{
		printf("enter 1 for top of stack and 2 for swap two elem3 for clear :");
		scanf("%d",&n);
		switch(n)
		{
			case 1:printf("%c",stack[--top]);
				 ++top;
				 break;
			case 2:
				 temp=stack[top-1];
				 stack[top-1]=stack[top-2];
				 stack[top-2]=temp;
				 
				 printf("after swap\n");
				 for(temp=0;temp<top;temp++)
		
			
					 printf("%c",stack[temp]);
				 break;
			case 3: for(temp=top-1;temp>=0;temp--)
					stack[temp]=0;
				printf("%c",stack[temp]);
				break;
			default:printf("*");
	}	}
}
		/*	switch(c)
			{
			case ' ':cnt=0;
				 break;
			case '+':push(pop()+pop());
		       		break;
			case '*':push(pop()*pop());
				break;
			case '-':op2=pop();
				push(pop()-op2);
				break;
	       		case '/':op2=pop();
	 			if(op2!=0.0)
	       			push(pop()/op2);
 				else
					printf("error:zero divisor");
			case '%':op2=pop();
				if(op2!=0.0)
			       push((int)pop()%(int)op2);
		 		else
			      printf("error");
			default:printf("%d",stack[--top]);
			}
		}
	}
	printf("%d",stack[0]);*/

void push(double  f)
{
	if(top<MAX)
	stack[top++]=f;
}
double  pop(void)
{
	if(top>-1)
	return	stack[--top];
}

       								
