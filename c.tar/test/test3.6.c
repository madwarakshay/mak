/*function itoa accepts three arguments  third argument is min field width*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
void itoa(int n,char s[],int fw);
void reverse(char s[]);
main()
{
	char s[20];
	int n,fw;
	printf("enter n;");
	scanf("%d",&n);
	printf("enter field width");
	scanf("%d",&fw);
//	n=~n;
//	n+=1;
	itoa(n,s,fw);
}
void itoa(int n,char s[],int fw)
{
	unsigned int k;
	int i=0,sign;
	k=n;
	if((sign=k)<0)
		k=-k;
	do
	{
		s[i++]=k%10+'0';
	}while((k/=10)>0);
	if(sign<0)
		s[i++]='-';
	for(i;i<fw;i++)
		s[i]=' ';
	s[i]='\0';
	reverse(s);
	
}
void reverse(char s[])
{
	int l,m;
	char temp;
	for(l=0,m=strlen(s)-1;m>l;l++,m--)
	{
		temp=s[l];
		s[l]=s[m];
		s[m]=temp;
	}
	puts(s);
}

