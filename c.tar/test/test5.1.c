/*getint treats + - not followed by a digit is valid represemtation of zero, fix it to push character back on input*/
#include<stdio.h>
#include<string.h>
#include<ctype.h>
int getint(int *);
int getch(void);
void ungetch(int );
char buf[100];
int bufp=0;
int main()
{
	int n,r,array[20];
	for(n=0;n<20 && (r=getint(&array[n]))!=EOF;n++)
	{
		if(r)
		{
			printf("your input number %d\n",array[n]);
		}
		else
		{
			printf("not ano");
		}
	}

		return 0;
}
int getint(int *p)
{
	int c,sign,c1;
	while(isspace(c=getch()))
		;
	if(!isdigit(c) && c!=EOF && c!='+' &&c!='-')
	{
		ungetch(c);
		return 0;
	}
	sign=(c=='-')?-1:1;
	if(c=='+' ||c=='-')
	{
		if(!isdigit(c1=getch()))
		{
			ungetch(c1);
			ungetch(c);
			return 0;
		}
		else
		{
			c=c1;
		}
	}
	for(*p=0;isdigit(c);c=getch())
		*p=10**p+(c-'0');
	*p*=sign;
	if(c!=EOF)
		ungetch(c);
	return(c);
}
int getch(void)
{
	return(bufp>0)?buf[--bufp]:getchar();
}
void ungetch(int c)
{
	if(bufp>=100)
		printf("ungetch: too many arguments\n");
	else
		buf[bufp++]=c;
}
	

