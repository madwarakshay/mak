/*modify fsize to print other information contained in inode*/
#define NAME_MAX 14
typedef struct
{
	long ino;
	char name[NAME_MAX+1];
}dirent;
typedef struct
{
	int fd;
	dirent d;
}DIR;
DIR *opendir(char *dirname);
dirent *readdir(DIR *dfd);
void closedir(DIR *dfd);
char *name;
struct stst stbuf;
int stat(char *,struct stat *);
stat(name,&stbuf);
struct stat
{
	dev_t st_dev;
	ino_t st_ino;
	short st_mode;
	short st_nlink;
	short st_uid;
	short st_gid;
	dev_t st_rdev;
	off_t st_size;
	time_t st_atime;
	time_t st_st_mtime;
	time_t st_ctime;
};

#include<stdio.h>
#include<string.h>
#include"syscalls.h"
#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat.h>
#include"direct.h"
void fsize(char *);
int main(int argc,char **argv)
{
	if(argc==1)
		fsize(".");
	else
	
		while(--argc>0)
			fsize(*++argv);
		return 0;
}
int stat(char *,struct stat *);
void dirwalk(char *,void (*fcn)(char *));
void fsize(char *name)
{
	struct stat stbuf;
	if(stat(name,&stbuf)==-1)
	{
		fprintf(stderr,"fsize:can't access %s\n",name);
		return;
	}

	/*if((stbuf.st_mode &S_IFMT)==S_IFDIR)
		dirwalk(name,fsize);
	prints("%8ld %s\n",stbuf.st_size,name);*/
}
#define MAX_PATH 1024
void dirwalk(char *dir,void (*fcn)(char *))
{
	char name[MAX_PATH];
	direct *dp;
	DIR*dfd;
	if((dp=readdir(dfd))!=NULL)
	{
		if(strcmp(dp->name,".")==0 ||strcmp(dp->name,"..")==0)
			continue;
		if(strlen(dir)+strlen(dp->name)+2>sizeof(name))
			fprintf(stderr,"dirwalk:name %s 5s too long\n",dir,dp->name	);
		else
		{
			sprintf(name," %s %s",dir,dp->name);
			(*fcn)(name);
		}
	}
	close(dfd);
}
#ifndef DIRSIZ
#define DIRSIZ 14
#endif
struct direct
{
	ino_t d_ino;
	char d_name[DIRSIZ];
};
int fstat(int fd,structstat *);
DIR *opendir(char *dirname)
{
	int fd;
	struct stat stbuf;
	DIR *dp;
	if((fd=open(dirname,O_RDONLY,0))==-1 ||fstat(fd,&stbuf)==-1 ||(stbuf.st_mode &S_IFMT)!=S_IFDIR ||(dp=(DIR *)malloc(sizeof(DIR)))==NULL)
		return NULL;
	dp->fd=fd;
	return dp;
}
void closedir(DIR *dp)
{
	if(dp)
	{
		close(dp->fd);
		free(dp);
	}
}
#include<sys/dir.h>
direct *readdir(DIR *dp)
{
	struct direct dirbuf;
	static direct d;
	while(read(dp->fd,(char *)&dirbuf,sizeof(dirbuf))==sizeof(dirbuf))
	{
		if(dirbuf.d_ino==0)
			continue;
		d.ino=dir.d_ino;
		strcpy(d.mname,dirbuf.d_name,DIRSIZ);
		d.name[DIRSIZ]='\0';
		return &d;
	}
	return NULL;
}
