/*** Write a program to count blanks, tabs, and newlines. 0***/
#include<stdio.h>
int main()
{
	int lcnt=0,bcnt=0,tcnt=0,c;
	while((c=getchar())!='!')
	{
		if(c=='\t')
				++tcnt;
			else if(c=='\n')
			{
				++lcnt;
			}
			else
			{
				++bcnt;
			}

	}
	printf("%d %d %d ",lcnt,bcnt,tcnt);
}
