/*function strrindex returns position of rightmost occurence*/
#include<stdio.h>
#include<string.h> 
int strindex(char s[],char sf[]);
main()
{
	int pos,k=0;
char pattern[]="abcd",c,line[20];
while((c=getchar())!='\n')
{
	line[k]=c;
	putchar(line[k]);
	k++;
}
pos=strindex(line,pattern);
printf("%d",pos);

}
int strindex(char line[],char pattern[])
{
	int i,j,k,pos=-1;
	for(i=0;line[i];i++)
	{
		for(j=i,k=0;pattern[k]!='\0' && line[j]==pattern[k];j++,k++)
			;
		if(k>0 && pattern[k]=='\0')
			pos=i;
	}
	return pos;
}




