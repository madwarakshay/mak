/***Write an alternate version of squeeze (s 1,s2) that deletes
each character in s 1 that matches any character in the string s2.***/
#include<stdio.h>
#include<string.h>
main()
{
	char str[30];
	int i,j;
	printf("enter string");
	scanf("%s",str);
	for(i=0;str[i];i++)
	{
		for(j=1;j<strlen(str);j++)
		{
			if(str[i]==str[j])
			{
				memmove(str+j,str+j+1,strlen(str+j+1)+1);
				--j;
			}
		}
	}
	printf("%s",str);
}
