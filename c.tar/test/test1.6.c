/***Verify that the expression qetchar
() I = EOF is 0 or 1. 0***/
#include<stdio.h>
int main()
{
	int c;
	c=getchar();
	int i=getchar()!=EOF;
	printf("%d",i);
	while(c!=EOF)
	{
		putchar(c);
		c=getchar();
	}
}
