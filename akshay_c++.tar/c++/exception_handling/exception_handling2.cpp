#include<iostream>
using namespace std;
void abc(int i)
{
	cout<<"in abc function :"<<endl;
	if(i)
		throw i;   /* throwing multiple times but catching only one time*/
}
int main()
{
	try
	{
		cout<<"in try block  :"<<endl;
		abc(10);
		abc(20);
		abc(0);
	}
	catch(int i)
	{
		cout<<"caught     !"<<endl;
		cout<<"the value caught is  :"<<i<<endl;
	}
	return 0;
}
	
