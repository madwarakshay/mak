#include<iostream>
using namespace std;
int main()
{
	try
	{
		cout<<"in try block  :"<<endl;
		throw 100;
	}
	catch(int i)
	{
		cout<<"caught     !"<<endl;
		cout<<"the value caught is  :"<<i<<endl;
	}
	return 0;
}
	
