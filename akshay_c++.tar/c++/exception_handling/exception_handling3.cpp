#include<iostream>
using namespace std;
void abc(int i)
{
	cout<<"in abc function :"<<endl;
	try
	{
	if(i)
		throw i;
	}	/* throwing multiple times and catching multiple time*/
	catch(int i)
	{
		cout<<"caught exception     !"<<endl;
		cout<<"the value caught is  :"<<i<<endl;
	}
}
int main()
{
	abc(10);
	abc(20);
	abc(0);
	return 0;
}
	
