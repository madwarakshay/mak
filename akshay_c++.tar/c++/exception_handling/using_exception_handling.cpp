#include<iostream>
using namespace std;
void divide(int a,int b)
{
	try
	{
		if(b<0)
			throw b;
		cout<<"output for "<<a<<"  and "<<b<<"is  :"<<a/b<<endl;
	}
	catch(int b)
	{
	cout<<"division cannot possible "<<endl;
	}
}
int main()
{
	int i,j;
	do
	{
		cout<<"enter numerator  value :"<<endl;
	       cin>>i;
	       	cout<<"enter denominator value :"<<endl;
		cin>>j;
		divide(i,j);
	}while(i!=0);
	return 0;
}


