#include<iostream>
#include<cstring>
using namespace std;
class abc
{
	public:
		char str[40];
		int number;
		abc()
		{
			*str=0;
			number=0;
		}
		abc(char *s,int n)
		{
			strcpy(str,s);
			number=n;
		}
};
int main()
{
	int i;
	try
	{
		cout<<"in try  ....enter integer val  :"<<endl;
			cin>>i;
		if(i>0)
			throw abc("positive",i);
		else
			throw abc("negative",i);
	}
	catch(abc a)
	{
		cout<<a.str<<endl;
		cout<<a.number<<endl;
	}
}

