#include<iostream>
#include<exception>
using namespace std;
template<typename type>
void abc(type i) 
{
	cout<<"in abc function :"<<endl;
	try
	{
	if(i)
		throw i;
	}	/* throwing multiple times and catching multiple time*/
	catch(int i)  
	{
		cout<<" int  caught exception     !"<<endl;
		cout<<"the value caught is  :"<<i<<endl;
	}
/*	catch(...)  //it will catch  all types of throws
	{
		cout<<"caught exception     !"<<endl;
		cout<<"the value caught is  :"<<i<<endl;
	}*/
}
void a()
{
	cout<<"in terminating function "<<endl;
	abort();
}
int main()
{
	set_terminate(a);
	abc(10);
	abc(20);
	abc('c');
	abc("akshay kumar");
	return 0;
}
	
