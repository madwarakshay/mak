#include<iostream>
#include<cstring>
using namespace std;
template<typename type>
void abc(type a)
{
	try
	{
		cout<<"in try...."<<endl;
		if(a)
			throw a;
	}
	catch(int b)
	{
		cout<<"in int  catch..."<<b<<endl;
	}
	catch(char b)
	{
		cout<<"in char catch  "<<b<<endl;
	}
	catch(const char *b)
	{
		cout<<"in string catch  "<<b<<endl;
	}
}
int main()
{
	abc(5);
	abc('c');
	abc("akshay kumar");
}
