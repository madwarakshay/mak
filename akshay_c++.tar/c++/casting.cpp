#include<iostream>
using namespace std;
int main()
{
	int i=100;
//	char c=i;//it is potentially unsafe (as the compiler can't tell wheather the integer will overflow the range of char or not). implicit conversion 
	char c=static_cast<char>(i);//it is explicit conversion.
	cout<<c<<endl;
}
