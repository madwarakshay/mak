#include<iostream>
using namespace std;
namespace ak
{
	int i,j;
	class abc
	{
		protected:
		int i,j;
		public:
		virtual void put(int a,int b)
		{
			i=a;
			j=b;
		}
		int sum()
		{
			return i+j;
		}
	};
	namespace m
	{
		int i,j;
		class v:public abc
		{
			int i,j;
			public:
			void put(int a,int b)
			{
				abc::i=a;
				abc::j=b;
			}
			int diff()
			{
				return abc::i-abc::j;
			}
		};


	}
}
using namespace ak;
int main()
{
	cout<<"enter i and j val :"<<endl;
//	cin>>ak::i>>ak::j;
	cin>>m::i>>m::j;
	abc a;
	a.put(m::i,m::j);
	cout<<"the sum is";
	cout<<a.sum()<<endl;
	m::v n;
	n.put(m::i,m::j);
	cout<<"the diff is :"<<n.diff()<<endl;
}
