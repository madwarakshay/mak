#include<iostream>
#include<strstream>
using namespace std;
int main()
{
	char str[50];
	ostrstream outs(str,sizeof(str));
	outs<<"abcdef"<<" ";;
	outs<<1234<<" ";
	outs<<"hi";
	outs<<ends;
	cout<<str<<endl;
	istrstream ins(str);
	int i;
	char a[6];
	ins>>a;
	ins>>i;
	cout<<a<<" "<<i<<" ";
	ins>>a;
	cout<<a<<endl;
}
