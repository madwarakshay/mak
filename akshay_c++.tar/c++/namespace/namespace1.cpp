#include<iostream>
using namespace std;
namespace ak
{
	int i,j;
	class abc
	{
		int i,j;
		public:
		void put(int a,int b)
		{
			i=a;
			j=b;
		}
		int sum()
		{
			return i+j;
		}
	};
}
using namespace ak;
int main()
{
	cout<<"enter i and j val :"<<endl;
//	cin>>ak::i>>ak::j;
	cin>>i>>j;
	abc a;
	a.put(i,j);
	cout<<"the sum is";
	cout<<a.sum()<<endl;
}
