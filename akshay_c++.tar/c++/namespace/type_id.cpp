#include<iostream>
#include<typeinfo>
using namespace std;
class abc
{
	int i;
};
int main()
{
	abc a;
	char i;
	char s;
	cout<<"type id of i is :"<<typeid(i).name()<<endl;
	cout<<"type id of s is :"<<typeid(s).name()<<endl;
	cout<<"type id of a is :"<<typeid(a).name()<<endl;
	if(typeid(i)==typeid(s))
		cout<<"both are same"<<endl;
	else
		cout<<"both are not same"<<endl;
}

