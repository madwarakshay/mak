#include<iostream>
using  std::cout;
using  std::cin;
using  std::endl;
int main()
{
	int i;
	cout<<"hi ...enter i val:"<<endl;
	cin>>i;
	cout<<"entered  val is "<<i<<endl;
}
