#include<iostream>
#include<strstream>
using namespace std;
int main()
{
	char str[50];
	strstream strio(str,sizeof(str), ios::in |ios::out);
	strio<<"akshay"<<" ";
	strio<<123<<" ";
	strio<<0x10<<" ";
	cout<<str<<endl;
	char s[10];
	int i,j;
	strio>>s>>i>>j;
	cout<<s<<" "<<i<<" "<<j<<endl;
}

