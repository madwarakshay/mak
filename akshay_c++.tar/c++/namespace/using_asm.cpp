#include<iostream>
using namespace std;
int main()
{
	int i;
	//asm("hlt");
	asm("MOV i,1h");
	cout<<"i val:"<<i<<endl;

}
