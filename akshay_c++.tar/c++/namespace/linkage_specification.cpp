#include<iostream>
using namespace std;
extern "C" int sum(int,int);
int main()
{
	int i,j;
	cout<<"enter i and j bval:"<<endl;
	cin>>i>>j;
	cout<<sum(i,j)<<endl;
}
int sum(int a,int b)
{
	cout<<"this links as c"<<endl;
	return a+b;
}
