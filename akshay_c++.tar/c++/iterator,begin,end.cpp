#include<iostream>
#include<cstdlib>
using namespace std;
template<class type>
class abc
{
	public:
		type *q;
	int c;
	//vector<type>a;
	public:
	abc(int i)
	{
		type *q = (type *)calloc(i,sizeof(int));
		cout<<"enter for :"<<i<<" elements :"<<endl;
		for(int j=0;j<i;j++)
		{
			cin>>q[j];
		}
		c=i;
		cout<<"elements:"<<endl;
		for(int j=0;j<c;j++)
			cout<<q[j]<<" ";
	}
	type * bbegin()
	{
		return q;
	}
	type * eend()
	{
		return q+c;
	}

};
int main()
{
	abc<int> a(5);
	int *x;
       x=a.bbegin();
//	cout<<*x<<endl;
	while(x!=a.eend())
	{
		cout<<*x<<" ";
		
		x++;
	}
}
	



