#include<iostream>
#include<map>
#include<cstring>
using namespace std;
class name
{
	char n[40];
	public:
	name()
	{
		strcpy(n,"  ");
	}
	name(char *s)
	{
		strcpy(n,s);
	}
	char* get()
	{
		return n;
	}
};
class phone
{
	long int no;
	public:
	phone(long int i)
	{
		no=i;
	}
	long int getno()
	{
		return no;
	}
};
bool operator<(name a,name b)
{
	return strcmp(a.get(),b.get())<0;
}
int main()
{
	int i;
	long int j;
	char str[40];
	map<name,phone>m;
	for(i=0;i<5;i++)
	{
	cout<<"enter name  :"<<endl;
	cin>>str;
	cout<<"enter phone no :"<<endl;
	cin>>j;
	m.insert(pair<name,phone>(name(str),phone(j)));
	}
	map<name,phone>::iterator p;
	do
	{
		cout<<"enter name to be find  :"<<endl;
		cin>>str;
	p=m.find(name(str));
	if(p!=m.end())
	{
		cout<<"the number for name :"<<str<<"  is :"<<p->second.getno()<<endl;
	}
	else
	{
		cout<<"invalid  name ...."<<endl;
		break;
	}
	}while(1);
}
	

	
