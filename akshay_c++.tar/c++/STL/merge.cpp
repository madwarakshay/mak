#include<iostream>
#include<list>
using namespace std;
int main()
{
	list<int>l1;
	list<int>l2;
	int i;
	for(i=0;i<10;i+=2)
		l1.push_back(i);
	for(i=1;i<10;i+=2)
		l2.push_back(i);
	list<int>::iterator p;
	p=l1.begin();
	cout<<"before merging..."<<endl;
	while(p!=l1.end())
	{
		cout<<*p<<" ";
		p++;
	}
	p=l2.begin();
	cout<<endl;
	while(p!=l2.end())
	{
		cout<<*p<<" ";
		p++;
	}
	cout<<"after merging...."<<endl;
	l1.merge(l2);
	p=l1.begin();
	while(p!=l1.end())
	{
		cout<<*p<<" ";
		p++;
	}
	cout<<"size of l2   :"<<l2.size()<<endl;
}



	
