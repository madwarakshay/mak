#include<iostream>
#include<list>
using namespace std;
int main()
{
	list<int>l;
	int i;
	for(i=0;i<10;i++)
	l.push_back(i);
	cout<<"size  ="<<l.size()<<endl;
	list<int>::iterator p=l.begin();
	cout<<"contents :";
	while(p!=l.end())
	{
		cout<<*p<<" ";
		p++;
	}
	cout<<endl<<endl;
	p=l.begin();
	cout<<"contents modified:";
	while(p!=l.end())
	{
		*p+=100;
		cout<<*p<<" ";
		p++;
	}
	cout<<endl;
}

