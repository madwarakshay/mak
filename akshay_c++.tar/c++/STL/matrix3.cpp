#include<iostream>
#include<vector>
using namespace std;
template<class type>
class matrix
{
	public:
	int l,m;
	vector<vector<type>>a;
	matrix(int i,int j)
	{
		l=i;
		m=j;
	}
	void put_matrix()
	{
		type k;
		for(int i=0;i<l;i++)
		{
			vector<type>b;
			for(int j=0;j<m;j++)
			{
				cout<<"enter element of matrix:"<<endl;
				cin>>k;
				b.push_back(k);
			}
			a.push_back(b);
		}
	}
	void get_matrix()
	{
		cout<<"the elements are :"<<endl;
		for(int i=0;i<l;i++)
		{
			for(int j=0;j<m;j++)
			{
				cout<<a[i][j]<<" ";
			}
			cout<<endl;
		}
	}
	matrix &operator=(matrix d)
	{
		for(int i=0;i<l;i++)
		{
			vector<type>n;
			for(int j=0;j<m;j++)
			{
			n.push_back(d.a[i][j]);	
			}
			a.push_back(n);
		}
		return *this;
	}	
	matrix operator+(matrix d)
	{
		matrix<type>s(l,m);
		for(int i=0;i<l;i++)
		{
			vector<type>n;
			for(int j=0;j<m;j++)
			{	
			n.push_back(a[i][j]+d.a[i][j]);
			}
			s.a.push_back(n);
		}
		return s;
	}	
	matrix operator-(matrix d)
	{
		matrix<type>s(l,m);
		for(int i=0;i<l;i++)
		{
			vector<type>n;
			for(int j=0;j<m;j++)
			{	
			n.push_back(a[i][j]-d.a[i][j]);
			}
			s.a.push_back(n);
		}
		return s;
	}
	matrix operator*(matrix d)
	{
	
		if(m==d.l)
		{
			cout<<"multipilcation possible"<<endl;
			matrix<type>s(d.m,l);
			for(int i=0;i<l;i++)
			{
				vector<type>n;
				int a=d.m;
					int b=0;
				while(a--)
				{
					type f=0;
					for(int j=0;j<d.m;j++)
					{
						f+=(this->a[i][j]*d.a[j][b]);
					}
			 			n.push_back(f);
						b++;
				}
				s.a.push_back(n);
			}
		
		return s;
		}
		else
		cout<<"multiplication not possible"<<endl;
	}
			
};
