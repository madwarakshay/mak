#include<iostream>
#include<map>
#include<string>
using namespace std;
int main()
{
map<string,int>m;
int i,j;
string str;
for(i=0;i<5;i++)
{
	cout<<"enter string..."<<endl;
	cin>>str;
	cout<<"enter no..."<<endl;
	cin>>j;
	m.insert(pair<string,int>(str,j));
}
cout<<"enter key..."<<endl;
cin>>str;
map<string,int>::iterator p=m.begin();
p=m.find(str);
if(p!=m.end())
	cout<<"found....with key  :"<<str<<" and no is : "<<p->second;
}




