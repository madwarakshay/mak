#include<iostream>
#include<list>
using namespace std;
int main()
{
	int i;
	list<int>l;
	for(i=0;i<10;i++)
	l.push_front(i);
	list<int>::iterator p=l.begin();
	while(p!=l.end())
	{
		cout<<*p<<" ";
		p++;
	}
	cout<<"reverse order"<<endl;
	p=l.end();
	while(p!=l.begin())
	{
		p--;
		cout<<*p<<" ";
	}
}
