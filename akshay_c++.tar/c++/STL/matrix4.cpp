#include"matrix3.cpp"
int main()
{
	matrix<char>m(2,2);
	matrix<char>n(2,2);
//	m.put_matrix();
	n.put_matrix();
//	m.get_matrix();
	n.get_matrix();
	matrix<char>a(2,2);
	a=n;
	a.get_matrix();
//	a=(m*n);
//	a.get_matrix();
}
