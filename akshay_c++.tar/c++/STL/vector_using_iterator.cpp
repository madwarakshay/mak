#include<iostream>
#include<vector>
using namespace std;
int main()
{
	vector<int>v;
	cout<<"initial size is :"<<v.size()<<endl;
	for(int i=0;i<10;i++)
		v.push_back(i);
	cout<<"final size is :"<<v.size()<<endl;
	for(int i=10;i<20;i++)
		v.push_back(i);
	cout<<"final size is :"<<v.size()<<endl;
	vector<int>::iterator p;
	p=v.begin();
	while(p!=v.end())
	{
		cout<<*p<<" ";
		p++;
	}
	cout<<"modified"<<endl;
	p=v.begin();
	while(p!=v.end())
	{
		*p+=1;
		cout<<*p<<" ";
		p++;
	}

}


