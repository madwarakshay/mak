#include<iostream>
#include<map>
using namespace std;
int main()
{
	map<int,char>m;
	int i;
	for(i=0;i<10;i++)
	m.insert(pair<int,char>(i,(char)('a'+i)));
	map<int,char>::iterator p;
	do
	{
	cout<<"enter int val :"<<endl;
	cin>>i;
	p=m.find(i);
	if(p!=m.end())
	cout<<"the character of key  "<<i<<"  is  :"<<p->second<<endl;
	else
	cout<<"invalid key..."<<endl;
	}while(i>=0 && i<10);
}
