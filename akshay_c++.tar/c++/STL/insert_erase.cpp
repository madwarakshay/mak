#include<iostream>
#include<vector>
using namespace std;
int main()
{
	int i;
	vector<char> v;
	vector<char> v1;
	for(i=0;i<10;i++)
	{
		v.push_back((char)(i+'a'));
	}
	vector<char>::iterator p=v.begin();
	p+=2;
	v.insert(p,10,'z');//inserted 'z' at third position in vector v
	cout<<"inserted"<<endl;
	for(i=0;i<v.size();i++)
		cout<<v[i]<<" ";
	p=v.begin();
	p+=2;
	v.erase(p,p+10);
	p=v.begin();
	cout<<"erased"<<endl;
	while(p!=v.end())
	{
		cout<<*p<<" ";
		p++;
	}
}

