#include<iostream>
using namespace std;
class base1
{
	public:
		virtual void fun()
		{
			cout<<"in base1"<<endl;
		}

};
class base2
{
	public:
		 virtual void fun()
		{
			cout<<" in base 2"<<endl;
		}
};
class derived : public base1, public  base2
{

	public:
	/*	void fun()
		{
			cout<<"in derived"<<endl;
		}
		void a()
		{
			cout<<"in derived"<<endl;
		}*/
};
int main()
{
	derived d;
	base1 *p;
	p=&d;
	p->fun();
}
