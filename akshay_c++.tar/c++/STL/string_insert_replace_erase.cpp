#include<iostream>
#include<string>
using namespace std;
int main()
{
	string str1("akshay kumar");
	string str2("madwar");
	//inserting...
	str1.insert(7,str2);//inserting str2 from 7th position of str1.
       cout<<str1<<endl;
       str1.erase(5,6);//erase str1 6 elements from 5th position.
       cout<<str1<<endl;
       str1.replace(5,6,str2);//replace 6 elements from 5th position with str2.
       cout<<str1<<endl;

}       
