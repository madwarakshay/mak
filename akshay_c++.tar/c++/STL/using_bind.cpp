#include<iostream>
#include<algorithm>
#include<functional>
#include<list>
using namespace std;
int main()
{
	list<int>l1;
	int i;
	for(i=0;i<10;i++)
		l1.push_back(i);
	list<int>::iterator p=l1.begin(),endp;
	endp= remove_if(l1.begin(), l1.end(), not1(bind1st(greater<int>(), 6)));
	p=l1.begin();
	while(p!=endp)
	{
		cout<<*p<<" ";
		p++;
	}
	return 0;
}
	
