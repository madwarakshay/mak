#include<iostream>
#include<vector>
#include<cstring>
using namespace std;
int main()
{
	int i;
	vector<char> v;
	vector<char> v1;
	for(i=0;i<10;i++)
	{
		v.push_back((char)(i+'a'));
	}
	vector<char>::iterator p=v.begin();
	p+=2;
	v.insert(p,10,'z');//inserted 'z' at third position in vector v
	cout<<"inserted"<<endl;
	for(i=0;i<v.size();i++)
		cout<<v[i]<<" ";
	p=v.begin();
	p+=2;
	v.erase(p,p+10);
	p=v.begin();
	cout<<"erased"<<endl;
	while(p!=v.end())
	{
		cout<<*p<<" ";
		p++;
	}
	char str[]="akshay kumar";
	for(i=0;i<strlen(str);i++)
		v1.push_back(str[i]);
	cout<<"inserting v2"<<endl;
	p=v.begin();
	p+=2;
	v.insert(p,'<');
	p++;
	v.insert(p,'>');
	v.insert(p,v1.begin(),v1.end());
	p=v.begin();
	cout<<"after inserting "<<endl;
	while(p!=v.end())
	{
		cout<<*p<<" ";
		p++;
	}
	cout<<"size of v is :"<<v.size()<<endl;
}

