#include<iostream>
#include<vector>
using namespace std;

class abc
{
	int a;
	public:
	abc()
	{
	a=0;
	}
	abc(int i)
	{
		a=i;
	}
	int get()
	{
		return a;
	}
};
int main()
{
	vector<abc> v;
	vector<abc> v1;
	int i;
	for(i=0;i<5;i++)
		v.push_back(abc(i));
	vector<abc>::iterator p=v.begin();
	while(p!=v.end())
	{
		cout<<p->get()<<" ";
		p++;
	}
	cout<<endl;
	for(i=0;i<5;i++)
		v1.push_back(abc(i+2));
	p=v1.begin();
	while(p!=v1.end())
	{
		cout<<p->get()<<" ";
		p++;
	}
	cout<<endl<<endl;
	p=v.begin();
	p+=2;
	v.insert(p,v1.begin(),v1.end());//inserting objects of v1 into v
	cout<<"inserted ..."<<endl;
	p=v.begin();
	while(p!=v.end())
	{
		cout<<p->get()<<" ";
		p++;
	}

}
