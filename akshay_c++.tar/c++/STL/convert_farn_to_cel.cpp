#include<iostream>
#include<vector>
using namespace std;
class abc
{
	int val;
	public:
	abc()
	{
	}
	abc(int i)
	{
		val=i;
	}
	int get()
	{
		return val;
	}
	abc &operator=(int i)
	{
		val=i;
		return *this;
	}
};
int main()
{
	vector<abc>v;
	int i;
	for(i=0;i<5;i++)
	{
		v.push_back(abc(rand()%100));
	}
	for(i=0;i<5;i++)
		cout<<v[i].get()<<" ";
	cout<<"converting  farn to cel  :"<<endl;
	for(i=0;i<5;i++)
	{
		v[i]=(int)((v[i].get())-32)*5/9;
	}
	cout<<"cel val is :"<<endl;
	for(i=0;i<5;i++)
		cout<<v[i].get()<<" ";
}



