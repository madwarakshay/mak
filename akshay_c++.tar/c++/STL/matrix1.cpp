#include<iostream>
#include<vector>
using namespace std;
int main()
{

	vector<vector<int>>a(int m,vector<int>(n));
	cout<<"enter no of rows"<<endl;
	cin>>m;
	cout<<"enter no of colums "<<endl;
	cin>>n;
	int i,j,k;
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			cout<<"enter element:"<<endl;
			a[i][j];
		}
	}
	cout<<"displaying matrix a:"<<endl;
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			cout<<a[i][j]<<" ";
		}
		cout<<endl;
	}
}
