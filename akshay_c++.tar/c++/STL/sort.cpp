#include<iostream>
#include<list>
using namespace std;
int main()
{
	int i;
	list<int>l;
	for(i=0;i<10;i++)
	l.push_front(rand()%1000);
	list<int>::iterator p=l.begin();
	while(p!=l.end())
	{
		cout<<*p<<" ";
		p++;
	}
	cout<<"sorting..."<<endl;
	l.sort();//sorting is done
	p=l.begin();
	while(p!=l.end())
	{
		cout<<*p<<" ";
		p++;
	}
}
