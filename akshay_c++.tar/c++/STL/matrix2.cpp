#include<iostream>
#include<vector>
using namespace std;
int main()
{
	int i,j,k;
	vector<vector<int>>a;
	for(i=0;i<2;i++)
	{
		vector<int>b;
		for(j=0;j<2;j++)
		{
			cout<<"enter element :"<<endl;
			cin>>k;
			b.push_back(k);
		}
		a.push_back(b);
	}
	cout<<"the elenents are  :"<<endl;
	for(i=0;i<2;i++)
	{
		for(j=0;j<2;j++)
		{
			cout<<a[i][j]<<" ";
		}
		cout<<endl;
	}
			
}
