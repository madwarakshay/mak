#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
int main()
{
	int i;
	vector<bool>v;
	for(i=0;i<10;i++)
	{
		if(rand()%2)
			v.push_back(true);
		else
			v.push_back(false);
	}
	cout<<"the sequence is  .."<<endl;
	for(i=0;i<v.size();i++)
	{
		cout<<boolalpha<<v[i]<<" ";
	}
	cout<<endl<<endl;
	i=count(v.begin(),v.end(),true);
	cout<<"no of true values are :"<<i<<endl;
}
