#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
int increment(int i)
{
	return ++i;
}
int main()
{
	vector<int>v;
	int i;
	for(i=0;i<10;i++)
	v.push_back(i);

	for(i=0;i<10;i++)
		cout<<v[i]<<" ";
	cout<<endl;
	vector<int>::iterator p=v.begin();
	p=transform(v.begin(),v.end(),v.begin(),increment);
	cout<<"transformed..."<<endl;
	for(i=0;i<10;i++)
		cout<<v[i]<<" ";
}


