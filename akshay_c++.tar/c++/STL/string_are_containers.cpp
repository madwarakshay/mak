#include<iostream>
#include<string>
using namespace std;
int main()
{
	string s1("akshay kumar madwar");
	string::iterator p=s1.begin();
	int i;
	for(i=0;i<s1.size();i++)
		cout<<s1[i];
	cout<<endl;
	cout<<"using iterator ...."<<endl;
	while(p!=s1.end())
	{
		cout<<*p++;
	}
}
