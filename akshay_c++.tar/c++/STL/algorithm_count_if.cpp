#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
int dividesby3(int i)
{
	if(i%3==0)
		return 1;
	else
		return 0;
}
int main()
{
	vector<int>v;
	int i;
	for(i=0;i<10;i++)
		v.push_back(i);
	cout<<"sequence is :"<<endl;
	for(i=0;i<10;i++)
		cout<<v[i]<<" ";
	i=count_if(v.begin(),v.end(),dividesby3);
	cout<<"numbers divisible by 3 are :"<<i<<endl;
}

