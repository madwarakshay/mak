#include<iostream>
#include<string>
using namespace std;
int main()
{
	string s1("akshay kumar kumar madwar");
	string s2;
	int i;
	i=s1.find("kumar");
	if(i!=string::npos)
		cout<<"match found in index  "<<i<<endl;
	cout<<"assigning remaining string to s2"<<endl;
	s2.assign(s1,i,s1.size()-i);
	cout<<s2<<endl;
	i=s1.rfind("kumar");
	if(i!=string::npos)
		cout<<"match found in index  "<<i<<endl;
	cout<<"assigning remaining string to s2"<<endl;
	s2.assign(s1,i,s1.size()-i);
	cout<<s2<<endl;//adding akshay at the end of s2 string
	s2.append(s1,0);
//	s2.append("akshay",6);
	cout<<s2<<endl;

}
	

