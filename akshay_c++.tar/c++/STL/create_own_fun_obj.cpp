#include<iostream>
#include<algorithm>
#include<list>
using namespace std;
class negatee : unary_function<double,double>  //creating our own object function
{
	public:
		result_type operator()(argument_type i)
		{
			return (result_type)-i;
		}
};
class addd : binary_function<int,int,int>
{
	public:
	result_type operator()(first_argument_type i,second_argument_type j)
	{
		return (result_type)(i+j);
	}
};

int main()
{
	list<int>l;
	list<int>l1;
	int i;
	for(i=0;i<10;i++)
		l.push_back(i);
	for(i=0;i<10;i++)
		l1.push_back(i);

	list<int>::iterator p=l.begin();
	while(p!=l.end())
	{
		cout<<*p<<" ";
		p++;
	}
	p=l.begin();
	p=transform(l.begin(),l.end(),l.begin(),negatee());
	cout<<"after transformed..."<<endl;
	p=l.begin();
	while(p!=l.end())
	{
		cout<<*p<<" ";
		p++;
	}
	p=l.begin();
	p=transform(l.begin(),l.end(),l1.begin(),l.begin(),addd());
	cout<<"after transformed...addd"<<endl;
	p=l.begin();
	while(p!=l.end())
	{
		cout<<*p<<" ";
		p++;
	}
}

