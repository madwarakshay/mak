#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
int main()
{
	vector<char>v;
	vector<char>v1(30);
	char str[]="The STL is power programming";
	int i;
	for(i=0;str[i];i++)
	v.push_back(str[i]);

	remove_copy(v.begin(), v.end(), v1.begin(), ' ');

	for(i=0;i<v1.size();i++)
		cout<<v1[i];
	return 0;
}
