#include<iostream>
#include<string>
#include<cstring>
using namespace std;
int main()
{
	string str1="akshay";
	std::string str2="kumar";
	string str3;
	cout<<str1<<endl;
	cout<<str2<<endl;
	str3=str1+str2;  //it is similar to strcat(str1,str2);
	cout<<str3<<endl;
	if(str3==str1+str2)//it is similar to strcmp(str3,str2+str1);
		cout<<"same"<<endl;
		string str4(str1);//it is similar to strcpy(str1,str2);
		cout<<str4<<endl;
		for(int i=0;i<str4.size();i++)
			cout<<str4[i]<<endl;
		std::string str5(str2,0,4);
		cout<<str5<<endl;
}

