#include<iostream>
#include<algorithm>
#include<functional>
#include<list>
using namespace std;
int main()
{
	list<double>l1;
	list<double>l2;
	int i;
	for(i=10;i<100;i+=10)
		l1.push_back((double)i);
	for(i=10;i<100;i+=10)
		l2.push_back(3.0);
	list<double>::iterator p=l1.begin();
	p=transform(l1.begin(),l1.end(), l2.begin(), l1.begin(), divides<double>());
	cout<<"divides by 3 is :"<<endl;
	p=l1.begin();
	while(p!=l1.end())
	{
		cout<<*p<<" ";
		p++;
	}
}


