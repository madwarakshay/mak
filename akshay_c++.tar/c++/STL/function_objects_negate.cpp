#include<iostream>
#include<algorithm>
#include<list>
using namespace std;
int main()
{
	list<int>l;
	int i;
	for(i=0;i<10;i++)
		l.push_back(i);

	list<int>::iterator p=l.begin();
	while(p!=l.end())
	{
		cout<<*p<<" ";
		p++;
	}
	p=l.begin();
	p=transform(l.begin(),l.end(),l.begin(),negate<int>());
	cout<<"after transformed..."<<endl;
	p=l.begin();
	while(p!=l.end())
	{
		cout<<*p<<" ";
		p++;
	}
}

