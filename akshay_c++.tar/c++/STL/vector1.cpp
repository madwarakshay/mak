#include<iostream>
#include<vector>
using namespace std;
int main()
{
	vector<int>v;
	cout<<"initial size is :"<<v.size()<<endl;
	for(int i=0;i<10;i++)
		v.push_back(i);
	cout<<"final size is :"<<v.size()<<endl;
	for(int i=10;i<20;i++)
		v.push_back(i);
	cout<<"final size is :"<<v.size()<<endl;
	for(int i=0;i<v.size();i++)
		cout<<v[i]<<" ";
}


