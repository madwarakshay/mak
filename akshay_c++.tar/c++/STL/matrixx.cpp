#include<iostream>
#include<vector>
using namespace std;
template<class type>
class matrix
{
	public:
	int l,m;
	vector<vector<type>>a;
	matrix(int i,int j)
	{
		l=i;
		m=j;
	}
	void put_matrix()
	{
		int k;
		for(int i=0;i<l;i++)
		{
			vector<type>b;
			for(int j=0;j<m;j++)
			{
				cout<<"enter element of matrix:"<<endl;
				cin>>k;
				b.push_back(k);
			}
			a.push_back(b);
		}
	}
	void get_matrix()
	{
		cout<<"the elements are :"<<endl;
		for(int i=0;i<l;i++)
		{
			for(int j=0;j<m;j++)
			{
				cout<<a[i][j]<<" ";
			}
			cout<<endl;
		}
	}
	matrix &operator=(matrix d)
	{
		for(int i=0;i<l;i++)
		{
			vector<type>n;
			for(int j=0;j<m;j++)
			{
			n.push_back(d.a[i][j]);	
			//a[i][j]=d.a[i][j];
			}
			a.push_back(n);
		}
		return *this;
	}	
	matrix operator+(matrix d)
	{
		matrix<type>s(l,m);
		for(int i=0;i<l;i++)
		{
			vector<type>n;
			for(int j=0;j<m;j++)
			{	
			n.push_back(a[i][j]+d.a[i][j]);
			}
			s.a.push_back(n);
		}
		return s;
	}	
	matrix operator-(matrix d)
	{
		matrix<type>s(l,m);
		for(int i=0;i<l;i++)
		{
			vector<type>n;
			for(int j=0;j<m;j++)
			{	
			n.push_back(a[i][j]-d.a[i][j]);
			}
			s.a.push_back(n);
		}
		return s;
	}
	matrix operator*(matrix d)
	{
	
		if(m==d.l)
		{
			cout<<"multipilcation possible"<<endl;
			matrix<type>s(d.m,l);
			for(int i=0;i<l;i++)
			{
				vector<type>n;
				int a=d.m;
					int b=0;
				while(a--)
				{
					type f=0;
					for(int j=0;j<d.m;j++)
					{
						f+=(this->a[i][j]*d.a[j][b]);
					}
			 			n.push_back(f);
						b++;
				}
				s.a.push_back(n);
			}
		
		return s;
		}
		else
		cout<<"multiplication not possible"<<endl;
	}
			
};
int main()
{
/*	matrix<int>m(2,2);
	matrix<int>c(2,2);
	matrix<int>e(2,2);
	matrix<int>f(2,2);
	m.put_matrix();
	cout<<"the elements are "<<endl;
	m.get_matrix();

	c=m;
	cout<<"the elements are :"<<endl;
	c.get_matrix();

	e=(m+c);
	cout<<"the addition matrix is:"<<endl;
	e.get_matrix();

	f=(m-c);
	cout<<"the subtraction  matrix is:"<<endl;
	f.get_matrix();
	f=(m*c);
	cout<<"multiplication output  is :"<<endl;
	f.get_matrix();*/
	matrix<int>m(2,3);
	matrix<int>c(3,3);
	matrix<int>x(m.l,c.m);
	m.put_matrix();
	m.get_matrix();
	c.put_matrix();
	c.get_matrix();
	x=(m*c);
	cout<<"multiplication of two matrix is :"<<endl;
	x.get_matrix();
}


