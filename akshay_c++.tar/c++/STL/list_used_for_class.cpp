#include<iostream>
#include<list>
using namespace std;
class abc
{
	int a;
	public:
	abc(int i)
	{
		a=i;
	}
	int get()
	{
		return a;
	}
	friend bool operator<(const abc &o1,const abc &o2);//we have to declare this overload operators if we are merging class , you may not using directly but compiler will use during merging operation of two classes. 
	friend bool operator>(const abc &o1,const abc &o2);
	friend bool operator==(const abc &o1,const abc &o2);
	friend bool operator!=(const abc &o1,const abc &o2);

	
};
bool operator<(const abc &o1,const abc &o2)
{
	return o1.a<o2.a;
}

bool operator>(const abc &o1,const abc &o2)
{
	return o1.a>o2.a;
}
bool operator==(const abc &o1,const abc &o2)
{
	return o1.a==o2.a;
}
bool operator!=(const abc &o1,const abc &o2)
{
	return o1.a!=o2.a;
}

int main()
{
	int i;
	list<abc>l1;
	list<abc>l2;
	for(i=0;i<5;i++)
		l1.push_back(abc(i));
	for(i=0;i<5;i++)
		l2.push_back(abc(rand()%10));
	cout<<"before merging..."<<endl;
	list<abc>::iterator p=l1.begin();
	while(p!=l1.end())
	{
		cout<<p->get()<<" ";
		p++;
	}
	p=l2.begin();
	while(p!=l2.end())
	{
		cout<<p->get()<<" ";
		p++;
	}
	cout<<"after merging..."<<endl;
	l1.merge(l2);
	p=l1.begin();
	while(p!=l1.end())
	{
		cout<<p->get()<<"  ";
		p++;
	}
}
