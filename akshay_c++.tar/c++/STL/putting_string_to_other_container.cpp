#include<iostream>
#include<string>
#include<list>
#include<vector>
#include<algorithm>
using namespace std;
int main()
{
	int i;
	string name;
	vector<string>v;
	list<string>l;
	for(i=0;i<5;i++)
	{
		cout<<"enter name.."<<endl;
		cin>>name;
		cout<<"inserting in vector..."<<endl;
		v.insert(v.begin()+i,1,name);
	//	v.push_back(name);  //it is same as above function.
		cout<<"inserting in list ...."<<endl;
		l.push_back(name);
	}
	list<string>::iterator q= l.begin();
	cout<<"printing list..."<<endl;
	while(q!=l.end())
	{
		cout<<*q<<" ";
		q++;
	}
	cout<<"printing vector..."<<endl;
//	reverse(v.begin(),v.end());
	for(i=0;i<v.size();i++)
	{
		cout<<v[i]<<" ";
	}
}


		
