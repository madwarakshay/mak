#include<vector>
using namespace std;
template<class type>
class matrix
{
	public:
	int l,m;
	vector< vector<type> >a;
 	matrix(int i,int j);
	void put_matrix();
        void get_matrix();
        matrix &operator=(matrix d);
        matrix operator+(matrix d);
        matrix operator-(matrix d);
        matrix operator*(matrix d);
};


