#include<iostream>
using namespace std;
class base
{
	protected:
		int val;
	public:
		void setval(int i)
		{
			val=i;
		}
		virtual void abc()=0;  /* pure virtual function */
};
class hexa : public base
{
	public:
		void abc()
		{
			cout<<"in hexa class   :"<<endl;
			cout<<hex<<val<<endl;
		}
};
class octa : public base
{
	public:
		void abc()
		{
			cout<<"in octa class   :"<<endl;
			cout<<oct<<val<<endl;
		}  
};
int main()
{
	hexa h;
	octa o;
	h.setval(25);
	o.setval(10);
	h.abc();
	o.abc();
}
