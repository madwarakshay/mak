#include<iostream>
using namespace std;
class base
{
	public:
		virtual void abc()
		{
			cout<<"in base class :"<<endl;
		}
};
class derived : public base
{
	public:
		void abc()
		{
			cout<<"in derived class   :"<<endl;
		}
};
int main()
{
	derived d;
	d.base::abc();  /* we can call base abc class like this */
	d.abc();
}
