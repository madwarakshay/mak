#include<iostream>
using namespace std;
class base
{
	public:
		virtual void abc()
		{
			cout<<"in base class :"<<endl;
		}
};
class derived : public base
{
	public:
		void abc()
		{
			cout<<"in derived class   :"<<endl;
		}
};
class derived2 : public base
{
	public:
	/*	void abc()
		{
			cout<<"in derived class   :"<<endl;
		}*/   /* not over written */
};
int main()
{
	derived d;
	derived2 d2;
	d.base::abc();  /* we can call base abc class like this */
	d.abc();
	d2.abc();  /* it calls the base abc function since no over written */
}
