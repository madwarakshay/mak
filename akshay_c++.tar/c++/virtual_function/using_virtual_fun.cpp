#include<iostream>
using namespace std;
class base
{
	protected:
		double val1;
		double val2;
	public:
		base(int i)
		{
			val1=i;
		}
		double getconv(void)
		{
			return val2;
		}
		double getval1()
		{
			return val1;
		}	
		virtual void  compute()=0;  /* pure virtual function  */

};
class l_to_g : public base
{
	public:
	l_to_g(int i) : base(i)
	{
	//	val1=i;
	}
	void compute()
	{
		val2=val1/3.7854;
	}
	

};
class f_to_c :public base
{
	public:
		f_to_c(int i) : base(i)
	{
	//	val1=i;
	}
		void compute()
		{
			val2=(val1-32) /1.8;
		}
};
int main()
{
	l_to_g a(10);
	f_to_c b(100);
	a.compute();
	b.compute();
cout<<"converted from"<<a.getval1()<<"litres to "<<a.getconv()<<"gallons"<<endl;
cout<<"converted from"<<b.getval1()<<"degrees farheinheit to "<<b.getconv()<<" degrees celcius"<<endl;
}
