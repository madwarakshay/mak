#include<iostream>
using namespace std;
class base
{
	public:
		virtual void abc()
		{
			cout<<"in base class :"<<endl;
		}
};
class derived : public base
{
	public:
		void abc()
		{
			cout<<"in derived class   :"<<endl;
		}
};
class derived2 : public derived
{
	public:
		void abc()
		{
			cout<<"in derived2 class  :"<<endl;  /* if derived class inherited virtual class from base and changed it , then it inherited by derived2 then the character of virtual we not go it can be still modified in derived2  */ 
		}
};
int main()
{
	derived d;
	derived2 d2;
	d.base::abc();  /* we can call base abc class like this */
//	d2.derived::abc();
	d.abc();
	d2.abc();
}
