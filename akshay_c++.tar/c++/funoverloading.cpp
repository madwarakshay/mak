#include<iostream>
#include<cstring>
using namespace std;
void stradd(char *s1,char *s2)
{
	strcat(s1,s2);
	cout<<"the added string is  :"<<s1<<"\n";
}
void stradd(char *s1,int i)
{
	char temp[10];
	sprintf(temp,"%d",i);
	strcat(s1,temp);
	cout<<"the added string 2 is  :"<<s1<<"\n";
}
int main()
{
	char str[]="abcdefgh";
	char str1[]="ijklmnop";
	stradd(str,str1);
	stradd(str,4);
	return(0);
}
