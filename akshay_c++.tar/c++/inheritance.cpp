#include<iostream>
using namespace std;
class building 
{
	int rooms;
	int floors;
	public:
	void set_rooms(int num);
	void set_floors(int num);
	int get_rooms(void);
	int get_floors(void);
};
class house : public building
{

	int baths;
	public:
	void set_baths(int num);
	int get_baths(void);
};
class school : public building
{
	int seminar_halls;
	public:
	void set_seminar_halls(int i);
	int get_seminar_halls(void);
};
void building :: set_rooms(int num)
{
	rooms=num;
}
void building :: set_floors(int num)
{
	floors=num;
}
int building :: get_rooms(void)
{
	return(rooms);
}
int building :: get_floors(void)
{
	return(floors);
}
void house :: set_baths(int num)
{
	baths=num;
}
int house :: get_baths(void)
{
	return(baths);
}


void school :: set_seminar_halls(int num)
{
	seminar_halls=num;
}
int school :: get_seminar_halls(void)
{
	return(seminar_halls);
}
int main()
{
	int i;
	building b;
	house h;
	school s;
cout<<"enter no of rooms for building"<<"\n";
cin>>i;
b.set_rooms(i);

cout<<"enter no of floors for building"<<"\n";
cin>>i;
b.set_floors(i);

cout<<"enter no of rooms for house"<<"\n";
cin>>i;
h.set_rooms(i);

cout<<"enter no of baths for house"<<"\n";
cin>>i;
h.set_baths(i);
	
cout<<"enter no of rooms for school"<<"\n";
cin>>i;
s.set_rooms(i);
	
cout<<"enter no of seminar halls for school"<<"\n";
cin>>i;
s.set_seminar_halls(i);
cout<<" the no of rooms for building is   :"<<b.get_rooms()<<"\n";
cout<<" the no of floors for building is   :"<<b.get_floors()<<"\n";
cout<<" the no of rooms for house is   :"<<h.get_rooms()<<"\n";
cout<<" the no of baths for house is   :"<<h.get_baths()<<"\n";
cout<<" the no of rooms for school is   :"<<s.get_rooms()<<"\n";
cout<<" the no of seminar halls  for school is   :"<<s.get_seminar_halls()<<"\n";
}
