#include<iostream>
using namespace std;
class base
{
	public:
		int a;
		base()
		{

		}

		base(int i)
		{
			cout<<"in base"<<endl;
			a=i;
		}
};
class derived1 : virtual public base
{
	public:
		int b;
		derived1() : base()
		{

		}
		derived1(int i,int j) : base(j)
		{
			cout<<"in  derived 1"<<endl;
			b=i;
		}
};
class derived2 : virtual public base
{
	public:
		int c;
		derived2():base()
		{

		}

		derived2(int i,int j):base(j)
	{

		cout<<"in derived 2"<<endl;
		c=i;
	}
};
class derived3 : public derived1,public derived2
{
	public:
		int d;
		derived3(int i,int j,int k) : derived2(j, k), derived2::base(k) 
	{
		d=i;
	}
};
int main()
{
	derived3 a(1,2,3);
	cout<<a.d<<" "<<a.c<<" " <<a.a<<endl;
//	cout<<a.derived2::a;
//	cout<<a.derived1::a;
}


