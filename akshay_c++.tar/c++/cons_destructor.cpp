#include<iostream>
using namespace std;
class stack
{
	int stck[10];
	int top;
	public:
	stack();
	~stack();
	void init();
	void push(int i);
	int pop(void);
};
stack :: stack()
{
	top=0;
	cout<<"stack initialised  "<<"\n";
}
stack :: ~stack()
{
	cout<<"stack destroyed  "<<"\n";
}
void stack :: init()
{
top=0;
}
void stack :: push(int i)
{
	if(top==10)
	{
		cout<<"stack is full"<<"\n";
	}
	else
	{
		stck[top]=i;
		top++;
	}
}
int stack::pop()
{
	if(top==0)
	{
		cout<<"stack is empty"<<"\n";
	}
	else
	{
		top--;
	}
		return(stck[top]);
}
int main()
{
	stack s1;
//	s1.init();
//	s2.init();
//	s1.push(4);
//	s1.push(5);
	for(int i=0;i<10;i++)
		s1.push(i+1);
//	cout<<"poped from s1 is   :"<<s1.pop()<<"\n";
	for(int i=0;i<10;i++)
	cout<<"poped from s1 is   :"<<s1.pop()<<"\n";
	return(0);
}
	
	
