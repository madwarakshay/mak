#include<iostream>
#include<vector>
using namespace std;
template<class T=int >
class abc
{
	public:
int rows;
int colums;
	vector<vector<T>> a;
	abc(int i,int j)
	{
		rows=i;
		colums=j;
		a.resize(rows);
		for(int i=0;i<rows;i++)
			a[i].resize(colums);
	}
	void put_matrix()
	{
		for(int i=0;i<rows;i++)
		{
			for(int j=0;j<colums;j++)
			{
				cout<<"enter element :"<<endl;
				cin>>a[i][j];
			}
		}
	}	

	class iterator
	{
		public:
			vector<T> *ptr;
			iterator()
			{

			}
			iterator(vector<T> *ptr1) 
			{
				ptr=ptr1;
			}
			iterator operator++(int x)
			{
				return ptr++;
			}
		friend	ostream &operator<<(ostream &out,iterator& p)
			{
		
				vector<int> :: iterator q=p.ptr->begin();
				while(q!=p.ptr->end())
				{
					cout<<*q<<" ";
						q++;
				}
								
					return out;
			}

			int operator<(const iterator p)
			{
				if(ptr<p.ptr)
					return 1;
				else
					return 0;
			}

	};

	vector<int>* begin()
	{
		return &a[0];
	}
	vector<int>* end()
	{
		return &a[rows];
	}
};

int main()
{
	abc<int> a(3,3);
	a.put_matrix();
	abc<int>::iterator p = a.begin();
	cout<<"the elements are"<<endl;
	for(p;p<a.end();p++)
	{
		cout<<p<<endl;
	}
}







	

