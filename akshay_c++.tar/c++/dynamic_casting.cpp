#include<iostream>
using namespace std;
class abc
{
	public:
		int a;
		virtual  void puta(int i)
		{
			cout<<"in base..."<<endl;
			a=i;
		}
		int geta()
		{
			return a;
		}
		 void print()
		{
			cout<<"in abc print...."<<endl;
		}

};
class xyz
{
	public:
		int c;
		void putc(int i)
		{
			c=i;
		}
		int getc()
		{
			return c;
		}
};
class efg : public abc,public xyz
{
	public:
		void puta(int i)
		{
			a=i;
			cout<<"in derived"<<endl;
		}
		void print()
		{
			cout<<"hello"<<endl;
		}
};

class mnop : public efg
{
	public:
		void puta(int i)
		{
			a=i;
			cout<<"in mnop"<<endl;
		}

};
int main()
{
	abc *a;
	xyz *x;
	efg *e,obj;
	mnop o;
	a=dynamic_cast<abc *>(&o);//derived class pointer can be casted into	base pointer but base pointer cannot cast into derived .
	a->puta(5);
/*	if(a==&obj)
		cout<<"same"<<endl;
	cout<<a->geta()<<endl;
	cout<<obj.geta()<<endl;
	a->print();
	x=dynamic_cast<xyz *>(&obj);
	x->putc(12);
	cout<<x->getc()<<endl;
	e->print();*/
}
	
