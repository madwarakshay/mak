#include<iostream>
#include<cstdlib>
using namespace std;
const int size=10;
template<class type>
class abc
{
	type a[size];
	public:
	abc()
	{
		for(int i=0;i<size;i++)
			a[i]=i;
	}
	type &operator[](int i)
	{
		return a[i];
	}
};
int main()
{
	int i;
	abc<int>ab;
	for(i=0;i<size;i++)
		cout<<"ab array is  :"<<ab[i]<<endl;
	ab[4]=9;
	for(i=0;i<size;i++)
		cout<<"ab array is  :"<<ab[i]<<endl;
}	
