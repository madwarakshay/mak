#include<iostream>
using namespace std;
template <class type>
void bubble(type *items,int count)
{
	int i,j;
	type a;
	for(i=0;i<count;i++)
	{
		for(j=count;j>i;j--)
		{
			if(items[j-1] < items[i])
			{
				a=items[j-1];
				items[j-1]=items[i];
				items[i]=a;
			}
		}
	}
}
int main()
{
	int arr[10]={1,2,3,4,6,7,8,9,10,5};
	char str[]="defabcghij";
	bubble(arr,10);
	for(int i=0;i<10;i++)
	cout<<arr[i]<<endl;
	bubble(str,10);
	cout<<"str :"<<str<<endl;
}

