#include<iostream>
#include<cstdlib>
#include<cstring>
using namespace std;
template<class type1, class type2>
void print(type1  a,type2 b)
{
	cout<<"a is :"<<a<<endl;
	cout<<"b is :"<<b<<endl;
}
template<class type1>
void mystrcat(type1 c,type1 d)
{
	strcat(c,d);
	cout<<"strcat is  ;"<<c<<endl;
}
int main()
{
	char str[]="abcdefgh";
	int a=10;
	char v[]="ijklmnop";
	print(v,str);
	mystrcat(str,v);
	return 0;
}
