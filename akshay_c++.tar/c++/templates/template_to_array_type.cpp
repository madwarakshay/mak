#include<iostream>
#include<cstdlib>
using namespace std;
template<class type,int size>
class abc
{
	type a[size];
	public:
	abc()
	{
		for(int i=0;i<size;i++)
			a[i]=i;
	}
	type &operator[](int i)
	{
		return a[i];
	}
};
int main()
{
	int i;
	abc<int,10>ab;
	for(i=0;i<10;i++)
		cout<<"ab array is  :"<<ab[i]<<endl;
	ab[4]=9;
	for(i=0;i<10;i++)
		cout<<"ab array is  :"<<ab[i]<<endl;
}	
