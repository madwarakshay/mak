#include<iostream>
using namespace std;
template <class X>
void swap1(X &a, X &b)
{
	X c;
	c=a;
	a=b;
	b=c;
}
int main()
{
	char c1='m', c2='n';
	int j=10, i=8;
	double d1=10.1, d2=23.3;
	swap1(c1, c2);
	cout<<"c1 :"<<c1<<" c2:"<<c2<<endl;
	swap1(i,j);
	cout<<"i  :"<<i<<" j  :"<<j<<endl;
	swap1(d1, d2);
	cout<<"d1 :"<<d1<<" d2:"<<d2<<endl;
	return 0;
}
