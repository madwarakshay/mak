#include<iostream>
using namespace std;
template<typename type>
class abc
{
	type a;
	public:
	abc(type b)
	{
		a=b;
	}
	type geta(void)
	{
		return a;
	}
};
template<>class abc<int>//it comes to this section only if abc class type is int
{
	int a;
	public:
	abc(int b)
	{
		a=(b+b);
	}
	int geta(void)
	{
		return a;
	}
};
int main()
{
	abc<char>v('c');
	cout<<"char a is :"<<v.geta()<<endl;
	abc<int>x(5);
	cout<<"x in int is  :"<<x.geta()<<endl;
}
