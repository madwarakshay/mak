#include<iostream>
using namespace std;
const int SIZE=10;
template<class type>
class abc
{
	type stack[SIZE];
	int top;
	public:
	abc()
	{
		top=0;
	}
	void push(type a)
	{
		if(top==SIZE)
			cout<<"stack is full"<<endl;
		else
		{
		stack[top]=a;
		top++;
		}
	}
	type pop(void)
	{
		if(top==0)
		cout<<"stack is empty"<<endl;
		else
		{
			top--;
			return stack[top];
		}
	}
};

int main()
{
	abc<int> a;
	a.push(5);
	a.push(6);
	cout<<"poped from class a is :"<<a.pop()<<endl;
	cout<<"poped from class a is :"<<a.pop()<<endl;
	abc<char>b;
	b.push('c');
	b.push('h');
	cout<<"poped from class b is :"<<b.pop()<<endl;
	cout<<"poped from class b is :"<<b.pop()<<endl;
}
		
