#include<iostream>
using namespace std;
ostream &setbasehex(ostream &out)
{
	out<<hex<<showbase;
	return out;
}
istream &details(istream &in)
{
	cout<<"enter name"<<endl;
}
int main()
{
	char name[20];
	cin>>details;
	cin>>name;
	cout<<name<<endl;
	cout<<123<<"   "<<setbasehex<<123<<endl;
}
