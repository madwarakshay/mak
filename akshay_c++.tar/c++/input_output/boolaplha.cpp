#include<iostream>
//#include<iomanip>
using namespace std;
int main()
{
	bool b;
	b=true;
	cout<<b<<"    "<<boolalpha<<b<<endl;
	b=0;
	cout<<"entered value is  :"<<b<<endl;
}

