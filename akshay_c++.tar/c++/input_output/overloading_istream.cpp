#include<iostream>
#include<cstring>
using namespace std;
class abc
{
	public:
	int roll;
	char name[20];
/*	abc(int n,char *b)
	{
		roll=n;
		strcpy(name,b);
	}*/
};
ostream &operator<<(ostream &out,abc a)  //overloading <<
{
//	out<<a.get_details()<<endl;
	out<<"the name is :"<<a.name<<endl;
	out<<"the roll no is : "<<a.roll<<endl;
	return out;
}
istream &operator>>(istream &in,abc &b)
{
	cout<<"enter name:"<<endl;
	in>>b.name;
	cout<<"enter roll :"<<endl;
	in>>b.roll;
	return in;
}
int main()
{
	abc a;
	cin>>a;
	cout << a;
//	cout<<"abcd"<<endl;
	return 0;
}

