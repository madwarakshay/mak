#include<iostream>
using namespace std;
ostream &setbasehex(ostream &out)
{
	out<<hex<<showbase;
	return out;
}
int main()
{
	cout<<123<<"   "<<setbasehex<<123<<endl;
}
