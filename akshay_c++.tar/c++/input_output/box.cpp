#include<iostream>
using namespace std;
class abc
{
	int x,y;
	public:
	abc(int a,int b)
	{
		x=a;
		y=b;
	}
	friend ostream &operator<<(ostream &out,abc v);
};
ostream &operator<<(ostream &out,abc v)
{
	int i,j;
	for(i=0;i<v.x;i++)
		out<<"*";
	out<<"\n";
	for(i=1;i<v.y-1;i++)
	{
		for(j=0;j<v.x;j++)
			if(j==0||j==v.x-1)
				out<<"*";
			else
				out<<" ";
		out<<"\n";
	}
	for(i=0;i<v.x;i++)
		out<<"*";
	return out ;
}
int main()
{
	abc a(15,5);
	cout<<a<<endl;
	abc b(15,5);
	cout<<b<<endl;
}
