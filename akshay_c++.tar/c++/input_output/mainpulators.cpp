#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
//	cout.width(5);//writing this is same as writing setw(10) in cout
	cout<<setfill('*')<<setw(10)<<left<<100<<endl;//setfill(),setw() are manipulators
}
