#include<iostream>
#include<cstring>
using namespace std;
class abc
{
	private:
	int roll;
	char name[20];
	public:
	abc(int n,char *b)
	{
		roll=n;
		strcpy(name,b);
	}
	void get_details()
	{
		cout<<"name is  :"<<name<<endl;
		cout<<"roll no is :"<<roll<<endl;
	}
friend ostream &operator<<(ostream &out,abc a);  //overloading <<
};
ostream &operator<<(ostream &out,abc a)  //overloading <<
{
	out<<a.name<<endl;
	out<<a.roll<<endl;
	return out;
}
int main()
{
	abc a(100,"akshay");
	cout << a;
	cout<<"abcd"<<endl;
	return 0;
}

