#include<iostream>
using namespace std;
int main()
{
	cout.precision(4);
	cout.width(10);
	cout.fill('*');
	cout<<left<<10.1234<<endl;
}
