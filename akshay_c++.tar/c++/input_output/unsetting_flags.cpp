#include<iostream>
using namespace std;
int main()
{
	cout.setf(ios::showpoint);
	cout.setf(ios::showpos);
//	cout<<showpoint<<showpos<<100.0<<endl;
	cout<<100.0<<endl;
	cout.unsetf(ios::showpoint);
	cout<<"after unsetting showpoint  :"<<endl;
	cout<<100.0<<endl;
	cout.unsetf(ios::showpos);
	cout<<"after unsetting showpos  :"<<endl;
	cout<<100.0<<endl;
	return 0;
}
