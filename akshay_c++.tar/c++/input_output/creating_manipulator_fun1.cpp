#include<iostream>
#include<cstring>
using namespace std;
istream &getdetails(istream &in)
{
	cout<<"enter password"<<endl;
}
int main()
{
	char paswd[10];
	do
	{
		cin>>getdetails;
		cin>>paswd;
	}while(strcmp(paswd,"akshay"));
	cout<<"correct password"<<endl;
}
	
