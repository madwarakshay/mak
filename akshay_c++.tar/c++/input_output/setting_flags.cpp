#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
//	cout.setf(ios::showpoint);
//	cout.setf(ios::showpos);
	cout<<showpoint<<showpos<<100.0<<endl;
	return 0;
}
