#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	cout<<setiosflags(ios::showpos);
	cout<<setiosflags(ios::showbase);
//	cout.setf(ios::hex, ios::basefield);//this is setting ios  flag or by using manipulators we can set hex like this 
       cout<<hex;	
	cout<<"hex :"<<123<<endl;



}
