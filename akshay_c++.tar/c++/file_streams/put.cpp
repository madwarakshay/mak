#include<iostream>
#include<fstream>
#include<cstring>
using namespace std;
int main()
{
	char str[40], *p;
	ofstream out;
	out.open("123",ios::out | ios::binary);
	if(!out.is_open())
		cout<<"cannot open file :"<<endl;
	do
	{
		cout<<"enter string    : ! for ending "<<endl;
		cin>>str;
		p=str;
		while(*p)
		{
			out.put(*p);
			p++;
		}
	}while(*str!='!');
	out.close();
	return 0;
}

