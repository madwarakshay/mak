#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	char str[40];
	ifstream in;// it is same as fscanf() 
	in.open("xyz",ios::in);
	do
	{
		in>>str;
	//	fscanf(fp,"%s",str); but it wont work because of file not opened with fopen()
	cout<<"str is :"<<str<<endl;
	}while(*str!='!');
	in.close();
	return 0;
}
		
