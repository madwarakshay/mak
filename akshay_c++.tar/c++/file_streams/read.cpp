#include<iostream>
#include<fstream>
#include<cstring>
using namespace std;
struct account
{
	char name[20];
	int account_no;
	int phone_no;
};
int main()
{
	struct account ak;
	ifstream in("details",ios::in);
	in.read((char*)&ak,sizeof(struct account));/* reading from file details to struct ak*/
	cout<<"count  :"<<in.gcount()<<endl;//to see how many bytes read 
	cout<<"name   :"<<ak.name<<endl;
	cout<<"account no :  "<<ak.account_no<<endl;
	cout<<"phone no  :"<<ak.phone_no<<endl;
	in.close();
	return 0;
}

