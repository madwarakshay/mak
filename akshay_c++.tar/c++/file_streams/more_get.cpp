#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	char str[10];
	ifstream in("123",ios::in);
	in.get(str,10,'!');//it reads until it gets '!' character in file 123 
	cout<<str<<endl;
}
