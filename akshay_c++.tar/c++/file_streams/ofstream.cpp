#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	char str[20]="ijklmnop";
	ofstream out;
	ifstream in;
	char name[10];
	int n;
	out.open("abc",ios::out);
	if(!out)
	{
		cout<<"error in opening the file"<<endl;
		return 1;
	}
	out<<"akshay"<<endl;
	out<<500<<endl;
	out<<"xyz"<<endl;
	out<<200<<endl;
	out.close();

	in.open("abc",ios::in);
	if(!in)
	{
		cout<<"error in opening file"<<endl;
	}
	in>>name>>n;
	cout<<name<<"   "<<n<<endl;
	in>>name>>n;
	cout<<name<<"   "<<n<<endl;
	in.close();

	return 0;
}

