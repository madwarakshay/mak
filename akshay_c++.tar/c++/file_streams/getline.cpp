#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	char str[20];
	ifstream in("123",ios::in | ios::binary);
	in.getline(str,10);//delimit dafaults to '\n'
//	in.getline(str,10,'y');
	cout<<str<<endl;
}
