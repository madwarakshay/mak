#include<iostream>
#include<fstream>
using namespace std;
void check_status(ifstream &in)
{
	ios::iostate i;
	i=in.rdstate();
	if(i & ios::goodbit)
		cout<<"no error occured..."<<endl;
	if(i & ios::eofbit)
	cout<<"end of file occured..."<<endl;
	else if(i & ios::failbit)
	cout<<"i/o error has occured..."<<endl;
	else if(i & ios::badbit)
	cout<<"fatal error has occured.."<<endl;
}
int main()
{
	char ch;
	ifstream in("123",ios::in | ios::binary);
	while(in)
	{
		in.get(ch);
		cout<<ch;
	}
	check_status(in);
	in.close();
	return 0;
}


