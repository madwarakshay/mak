#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	char ch;
	ifstream in("123",ios::in | ios::binary);
	while(!in.eof())//it is similar as while(in);
	{
		cout<<"peeked char :"<<(char)in.peek()<<endl; /* it gives the next chatacter from file */ 
		in.get(ch);
		cout<<ch;
	}
	in.close();
	return 0;
}

