#include<iostream>
#include<fstream>
using namespace std;
class abc
{
	public:
	char name[20];
	int phone_no;
	friend istream &operator>>(istream &in,class abc &a);
	friend ostream &operator<<(ostream &out,class abc a);
	friend ofstream &operator<<(ofstream &out,class abc a);
};
int main()
{
	abc a;
	cin>>a;
	ofstream v("phone",ios::out | ios::app);
	v<<a;//writing to disk    by writing << operator overloading it applies to the filesystem also it is the main use of c++
	cout<<a;
	v.close();
	return 0;
}
istream &operator>>(istream &in,class abc &a)
{
	cout<<"enter name.."<<endl;
	in>>a.name;
	cout<<"enter phone no..."<<endl;
	in>>a.phone_no;
	return in;
}
ostream &operator<<(ostream &out,class abc a)
{
	out<<"name is :  "<<a.name<<endl;
	out<<"phone no is ...:"<<a.phone_no<<endl;
	return out;
}
ofstream &operator<<(ofstream &out,class abc a)
{
	out<<"hi...."<<endl;
	out<<"name is :  "<<a.name<<endl;
	out<<"phone no is ...:"<<a.phone_no<<endl;
	return out;
}
