#include<iostream>
#include<fstream>
#include<cstring>
using namespace std;
struct account
{
	char name[20];
	int account_no;
	int phone_no;
};
int main()
{
	account ak;
	strcpy(ak.name,"akshay");
	ak.account_no=3313;
	ak.phone_no=8185;
	ofstream out("details",ios::out);
	out.write((char*)&ak,sizeof(struct account));
	ifstream in("details",ios::in);
	in.read((char*)&ak,sizeof(struct account));
	cout<<"name:"<<ak.name<<"  "<<"acc no:"<<ak.account_no<<"  "<<"phone:"<<ak.phone_no<<endl;
	out.close();
	return 0;
}

