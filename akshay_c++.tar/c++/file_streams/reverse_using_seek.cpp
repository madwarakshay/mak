#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	char c1,c2;
	fstream abc("123",ios::in | ios::out | ios::binary);
	int i,j;
	for(i=0,j=6;i<j;i++,j--)
	{
		abc.seekg(i,ios::beg);
		abc.get(c1);
	//	cout<<c1;
		abc.seekg(j,ios::beg);
		abc.get(c2);

		abc.seekp(i,ios::beg);
		abc.put(c2);
		abc.seekp(j,ios::beg);
		abc.put(c1);
	}
	abc.close();
	return 0;
}
