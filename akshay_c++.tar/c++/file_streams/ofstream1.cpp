#include<iostream>
#include<fstream>
using namespace std;
int main(int argc,char **argv)
{
	char str[40];
	if(argc!=2)
	{
		cout<<"error  :"<<endl;
		return 1;
	}
	ofstream out(argv[1] ,ios::out | ios::app);
	if(!out.is_open())
	{
		cout<<"sorry cannot open file  :"<<endl;
	}
	do
	{
		cout<<"enter string.... !for stop :"<<endl;
		cin>>str;
		out<<str<<endl;
	}while(*str!='!');
	out.close();
		return 0;
}

