#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	char ch;
	fstream abc("123",ios::in | ios::out | ios::binary);
	abc.seekg(2,ios::beg);
	abc.get(ch);
	cout<<ch;
	abc.close();
	return 0;
}

