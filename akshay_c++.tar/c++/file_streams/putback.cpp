#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	char ch;
	ifstream in("123",ios::in | ios::binary);
	while(in)
	{
		in.get(ch);
		cout<<ch;
		in.putback(ch);//it gives infinite loop printing first character from file 123 because putback puts the character in the same position so  get  function takes again  and prints which leads to infinite loop 
	}
	in.close();
	return 0;
}

