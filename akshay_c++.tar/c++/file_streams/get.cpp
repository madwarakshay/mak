#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	char ch;
	ifstream in;
	in.open("xyz",ios::in | ios::binary);
	if(!in.is_open())
	cout<<"cannot open file"<<endl;
	while(in)
	{
	in.get(ch);//it will get character by character from file xyz
	cout<<ch;
	}
	in.close();
	return 0;
}


