#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	char ch;
	fstream abc("123",ios::in | ios::out | ios::binary);
	abc.seekp(2,ios::beg);//it moves pointer two postions from beginning
	abc.put('l');//it replaces the character with l
	abc.get(ch);
	abc.close();
	return 0;
}
