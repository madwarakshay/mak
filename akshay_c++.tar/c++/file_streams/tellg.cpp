#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	char ch;
	ifstream in("123",ios::in | ios::binary);
//	in.ignore(1,'!');//it ignores first two characters from the file
	while(in)
	{
		cout<<in.tellg()<<endl;//it gives the current position
		in.get(ch);
		cout<<ch<<endl;
	//	cout<<in.tellg()<<endl;//it gives the current position
	}
	in.close();
	return 0;
}
