#include<iostream>
using namespace std;
int main()
{
	int a,b;
	cout<<"enter integer values ."<<"\n";
	cin>>a>>b;
	cout<<"the sum is : "<<a+b<<"\n";
}
