#include<iostream>
using namespace std;
class abc
{
	static int a;
	int b;
	public:
	void set_val(int c,int d)
	{
		a=c;
		b=d;
	}
	void show(void);
};
int abc :: a=5;
void abc :: show(void)
{
	cout<<"static val  :"<<a<<"\n";
	cout<<"not static val b :"<<b<<"\n";
}
int main()
{
	abc a, b;
	a.set_val(2,2);
	a.show();
	b.set_val(3,4);
	b.show();
	a.show();
}
