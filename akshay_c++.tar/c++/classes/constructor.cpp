#include<iostream>
#include<cstring>
using namespace std;
class abc
{
	char author[40];
	char title[30];
	char status[10];
	public:
	abc(char *a,char *t,char *s);
	void show(void);
};
abc :: abc(char *a,char *t,char *s)
{
	strcpy(author,a);
	strcpy(title,t);
	strcpy(status,s);
}
void abc :: show(void)
{
	cout<<"author is  :"<<author<<"\n";
	cout<<"title is :"<<title<<"\n";
	cout<<"status is :"<<status<<"\n";
}
int main()
{
	abc a("akshay","wings","alive");
	abc b("sri","123","alive");
	a.show();
	b.show();
}


