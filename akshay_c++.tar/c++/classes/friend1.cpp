#include<iostream>
using namespace std;
class square;
class rectangle
{
	int length,breadth;
	public:
	int area()
	{
		return(length*breadth);
	}
	void get(square a);
};
class square
{
	int side,height;
	public:
	void set_side(int a,int b)
	{
		side=a;
		height=b;
	}
	friend void rectangle::get(square);
	
};
void rectangle :: get(square a)
{
	length=a.side;
	breadth=a.height;
}
int main()
{
	rectangle r;
	square s;
	s.set_side(5,4);
	r.get(s);
	cout<<"area  :"<<r.area();
}
	
