#include<iostream>
using namespace std;
const int IDLE=0;
const int INUSE=1;
class c2;
class c1
{
	int status;
	public:
	void set_status(int s);
	friend int idle(c1 a,c2 b);
};
class c2 : public c1{ };
void c1 :: set_status(int s)
{
	status=s;
}
int idle(c1 a,c2 b)
{
	if(a.status || b.status)
		return 0;
	else
		return 1;
}
int main()
{
	c1 a;
	c2 b;
	a.set_status(INUSE);
	b.set_status(IDLE);
	if(idle(a,b))
	{
	cout<<"both are idle "<<"\n";
	}
	else
	cout<<"in use"<<"\n";
}


