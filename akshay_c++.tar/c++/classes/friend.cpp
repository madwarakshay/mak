#include<iostream>
using namespace std;
class myclass
{
	int a,b;
	public:
	friend int sum(myclass c);
	int set(int num1,int num2);
};
int myclass :: set(int num1,int num2)
{
	a=num1;
	b=num2;
}
int sum(myclass c)
{
	return c.a+c.b;
}
int main()
{
	myclass x;
	x.set(5,4);
	cout<<"sum is   :"<<sum(x)<<"\n";
}

