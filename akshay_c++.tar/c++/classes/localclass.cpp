#include<iostream>
using namespace std;
void fun(void);
int main()
{
	fun();
	return 0;
}
void fun(void)
{
	class abc
	{
		int i;
		public:
		void put_val(int n)
		{
			i=n;
		}
		int get_val(void)
		{
			return i;
		}
	}a;
	a.put_val(5);
	cout<<"val is : "<<a.get_val()<<endl;
}
