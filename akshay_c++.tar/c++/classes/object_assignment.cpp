#include<iostream>
using namespace std;
class abc
{
	int i;
	public:
	void set_val(int n)
	{
		i=n;
	}
	int get_val(void)
	{
		return i;
	}
};
int main()
{
	abc a,b;
	a.set_val(4);
	b=a;
	cout<<"val of b is :"<<b.get_val()<<endl;
}
 
