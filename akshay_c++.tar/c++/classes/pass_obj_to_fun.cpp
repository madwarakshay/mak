#include<iostream>
using namespace std;
class abc
{
	int i;
	public:
	abc(int n);
	~abc();
	void set_val(int n)
	{
		i=n;
	}
	int get_val(void);
};
abc :: abc(int n)
{
	i=n;
}
abc :: ~abc()
{
	cout<<"destructor"<<endl;
}
int abc :: get_val(void)
{
	return i;
}
void fun(abc a);
int main()
{
	abc a(1);
	fun(a);
	cout<<"i val in main  :"<<endl;
	cout<<a.get_val()<<endl;
}
void fun(abc a)
{
	a.set_val(5);
	cout<<"in function :"<<a.get_val()<<endl;
}

