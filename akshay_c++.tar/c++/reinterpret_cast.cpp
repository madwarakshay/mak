#include<iostream>
using namespace std;
class abc
{
	public:
		int a,b;
		void puta(int i)
		{
			a=i;
		}
		int geta()
		{
			return a;
		}
};
class efg : public abc 
{
	public:
		int a,b;
		void putb(int i)
		{
			b=i;
		}
		int getb()
		{
			return b;
		}
};
int main()
{
	abc *a;
	efg *e;
	e=reinterpret_cast<efg *>(a);
	e->puta(6);
	cout<<e->geta()<<endl;
	cout<<a->geta()<<endl;
}


