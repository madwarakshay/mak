#include<iostream>
#include<cstring>
using namespace std;
void mystrcat(char *s1, char *s2)
{
	while(*s1)
	s1++;
	while(*s2)
	{
		*s1=*s2;
		s1++;
		s2++;
	}
	*s1='\0';
}
int main()
{
	char str1[40]="abcdefgh";
	char str2[40]="ijklmnop";
	mystrcat(str1,str2);
	cout<<"the string is :"<<str1<<endl;
}
