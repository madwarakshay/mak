#include<iostream>
using namespace std;
class abc
{
	int lat;
	int longi;
	public:
	abc()
	{
	}
	abc(int a,int b)
	{
		lat=a;
		longi=b;
	}
	abc operator,(abc op2)
	{
		abc temp;
		temp.lat=op2.lat;
		temp.longi=op2.longi;
		cout<<"lat  :"<<temp.lat<<"  "<<"longi  :"<<temp.longi<<endl;
		return temp;
	}
	abc operator-(abc op2)
	{
		abc temp;
		temp.lat=lat-op2.lat;
		temp.longi=longi-op2.longi;
		return temp;
	}
	abc operator+=(abc op2)
	{
		lat=lat+op2.lat;
		longi=longi+op2.longi;
		return *this;
	}
	abc operator-=(abc op2)
	{
		lat=lat-op2.lat;
		longi=longi-op2.longi;
		return *this;
	}
	abc operator*(abc op2)
	{
		abc temp;
		temp.lat=lat*op2.lat;
		temp.longi=longi*op2.longi;
		return temp;
	}
	void show(void)
	{
		cout<<lat<<"   "<<longi<<endl;
	}
	abc operator()(int i,int j)
	{
		lat=i;
		longi=j;
		return *this;
	}
	friend abc operator+(abc op1,abc op2);/* in friend function no this pointer exists we have to send both operands to function  */

};
abc operator+(abc op1,abc op2)
{
abc temp;
temp.lat=op1.lat+op2.lat;
temp.longi=op1.longi+op2.longi;
return temp;
}
int main()
{
	abc a(10,20),b(20,30),c;
	a.show();
	b.show();
	c=a*b;
	cout<<"mul of two obj's  :"<<endl;
	c.show();
	c=a-b(5,6);
	cout<<"sub of two obj's  :"<<endl;
	c.show();
	a+=b;
	cout<<"+= of two obj's :  "<<endl;
	a.show();
	a-=b;
	cout<<"-= of two obj's :  "<<endl;
	a.show();
	c=c,a;
	c.show();
	c=a+b;
	c.show();
	
}



