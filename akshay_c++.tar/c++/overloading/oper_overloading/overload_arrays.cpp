#include<iostream>
using namespace std;
class abc
{
	int arr[4];
	public:
	abc(int i,int j,int k,int l)
	{
		arr[0]=i;
		arr[1]=j;
		arr[2]=k;
		arr[3]=l;
	}
/*	int operator[](int i)
	{
		return arr[i];
	}*/
	int &operator[](int i)
	{
		return arr[i];
	}
	void show()
	{
			cout<<"array elements are  :"<<endl;
		for(int i=0;i<4;i++)
		{
			cout<<i<<"  "<<arr[i]<<endl;
		}
	}
};
int main()
{
	abc a(1,2,3,4);
	a.show();
	a[0]=5;
	a.show();
	return 0;
}

