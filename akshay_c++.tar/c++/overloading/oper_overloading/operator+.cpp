#include<iostream>
using namespace std;
class abc 
{
	int latitude;
	int longitude;
	public:
	abc(int a,int b)
	{
		latitude=a;
		longitude=b;
	}
	abc operator+(abc a)
	{
		abc temp(0,0);
		temp.latitude=a.latitude + latitude;
		temp.longitude=a.longitude + longitude;
		return temp;
	}
	void show(void)
	{
		cout<<"latitude is :"<<latitude<<endl;
		cout<<"longitude is :"<<longitude<<endl;
	}
};
int main()
{
	abc a(10,15), b(20,30);
	a=a+b;
	a.show();
}
