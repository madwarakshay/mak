#include<iostream>
using namespace std;
class abc
{
	int length;
	int breadth;
	public:
	abc operator++()/* this is used to pre increment*/ 
	{
		length++;
		breadth++;
		return *this;
	}
	abc operator--()/* this is used to pre decrement*/ 
	{
		length--;
		breadth--;
		return *this;
	}
	abc operator--(int x)/* this is used to post decrement*/
	{
		length--;
		breadth--;
		return *this;
	}
	abc operator++(int x)/* this is used to post increment*/
	{
		length++;
		breadth++;
		return *this;
	}
	 abc(void)
	{
		cout<<"enter length  :"<<endl;
		cin>>length;
		cout<<"enter breadth  :"<<endl;
		cin>>breadth;
	}
	void show()
	{
		cout<<"length is :"<<length<<endl;
		cout<<"breadth is :"<<breadth<<endl;
	}

};
int main()
{
	abc a,b;
	a.show();
	b.show();
	a--;
	a.show();
	++b;
	b.show();

}
