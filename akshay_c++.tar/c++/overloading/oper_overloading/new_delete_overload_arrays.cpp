#include<iostream>
#include<new>
using namespace std;
class abc 
{
	int length,breadth;
	public:
	void *operator new[](size_t size)
	{
		void *p;
		cout<<"in new   "<<endl;
		p=malloc(size);
		return p;
	}
	void operator delete[](void *p)
	{
		cout<<"in delete  "<<endl;
		free(p);
	}
	void add_data()
	{
		cout<<"enter length "<<endl;
		cin>>length;
		cout<<"entr breadth  "<<endl;
		cin>>breadth;
	}
	void show()
	{
		cout<<"length"<<length<<endl;
		cout<<"breadth"<<breadth<<endl;
	}
};
int main()
{
	abc *p1;
	p1=new abc[2];
	for(int i=0;i<3;i++)
	p1[i].add_data();
	for(int i=0;i<3;i++)
		p1[i].show();
	delete[] p1;
}

