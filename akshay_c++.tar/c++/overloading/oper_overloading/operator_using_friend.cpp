#include<iostream>
using namespace std;
class abc
{
	int length;
	int breadth;
	public:
	friend abc operator++(abc &op2);
	friend abc operator--(abc &op2);
	friend void operator++(abc &op2,int x);
	friend abc operator--(abc &op2,int x);
	 abc(void)
	{
		cout<<"enter length  :"<<endl;
		cin>>length;
		cout<<"enter breadth  :"<<endl;
		cin>>breadth;
	}
	void show()
	{
		cout<<"length is :"<<length<<endl;
		cout<<"breadth is :"<<breadth<<endl;
	}
};
	abc operator++(abc &op2)/* this is used to post increment(a++) for friend*/ 
	{
		op2.length++;
		op2.breadth++;
		return op2;
	}
	abc operator--(abc &op)/* this is used to post decrement(a--) for friend*/ 
	{
		op.length--;
		op.breadth--;
		return op;
	}
	abc operator--(abc &op2,int x)/* this is used to pre decrement(--a) for friend */
	{
		op2.length--;
		op2.breadth--;
		return op2;
	
	}
	void operator++(abc &op2,int x)/* this is used to pre increment(++a) for friend */
	{
		op2.length++;
		op2.breadth++;
	//	return op2
		
	}
	 
int main()
{
	abc a,b;
	a.show();
	b.show();
	a--;
	a.show();
	++b;
	b.show();

}
