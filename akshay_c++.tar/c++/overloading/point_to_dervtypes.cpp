#include<iostream>
using namespace std;
class abc 
{
	int i;
	public:
	void set_i(int n)
	{
		i=n;
	}
	int get_i(void)
	{
		return i;
	}
};
class derived : public abc
{
	int j;
	public:
	void set_j(int n)
	{
		j=n;
	}
	int get_j(void)
	{
		return j;
	}
};
int main()
{
	abc *p;
	derived d[2];
	p=d;
	d[0].set_i(5);
	d[1].set_i(7);
	cout<<p->get_i()<<endl;
	p=d+1;
	cout<<p->get_i()<<endl;
}
