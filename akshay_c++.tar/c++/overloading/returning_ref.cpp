#include<iostream>
#include<cstring>
using namespace std;
char &replace(int i);
char s[40]="abcdef hijkl";
int main()
{

	replace(6)='G';
	cout<<"string   :"<<s<<endl;
}
char &replace(int i)
{
	return s[i];
}

