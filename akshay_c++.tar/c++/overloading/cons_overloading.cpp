#include<iostream>
using namespace std;
class abc
{
	int date,month,year;
	public:
	abc()
	{
		cout<<"enter date  :"<<endl;
		cin>>date;
		cout<<"enter month  :"<<endl;
		cin>>month;
		cout<<"enter year  :"<<endl;
		cin>>year;
	}
	abc(int d,int m,int y)
	{
		date=d;
		month=m;
		year=y;
	}
	void get_val(int &d1,int &m1,int &y1)
	{
		d1=date;
		m1=month;
		y1=year;
	}
};
int main()
{
	abc a;
	int d,m,y;
	abc b(8,7,2019);
	a.get_val(d,m,y);
	cout<<"date:"<<d<<" month  :"<<m<<" year"<<y<<endl;
	b.get_val(d,m,y);
	cout<<"b : date:"<<d<<" month  :"<<m<<" year"<<y<<endl;
}
