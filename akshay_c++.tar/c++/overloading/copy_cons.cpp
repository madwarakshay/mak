#include<iostream>
#include<new>
using namespace std;
class abc
{
	int *p;
	int size;
	public:
	abc(int i)
	{
		p=new int[i];
		if(!p)
			cout<<"allocation failed"<<endl;
		size=i;
	}
	abc(abc &a)
	{
		p=new int[a.size];
		for(int i=0;i<a.size;i++)
			p[i]=a.p[i];
	}
	void put(int i,int j)
	{
		if(i>=0 &&i<size)
			p[i]=j;
	}
	int get(int i)
	{
		return p[i];
	}
};
int main()
{
	abc a(10);
	for(int i=0;i<10;i++)
		a.put(i,i);
	for(int i=0;i<10;i++)
		cout<<"value is :"<<a.get(i)<<endl;
	abc x(a);
	for(int i=0;i<10;i++)
		cout<<x.get(i)<<endl;
	return 0;
}



