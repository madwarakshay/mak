#include<iostream>
using namespace std;
class abc
{
	public:
		int a;
		virtual void puta(int i)
		{
			cout<<"in base.."<<endl;
			a=i;
		}
		 int geta()//if the function is not virtual function then priority function will be derived in this program .in this puta is virtual function so it comes to base puta function .
		{
			cout<<"in base geta"<<endl;
			return a;
		}
		virtual	void print()
		{
			cout<<"hi....."<<endl;
		}

};
class efg : public abc
{
	public:
		int a;
		void puta(int i)
		{
			cout<<"in derived class "<<endl;
			a=i;
		}
		int geta()//if no geta function is written in derived class then it goes to base geta function , if geta function is written in derived class with no virtual then it calls the derived geta function.
		{
			cout<<"in derived geta function"<<endl;
			return abc::a;
		}
		void print()
		{
			cout<<"hello"<<endl;
		}
};
int main()
{
	abc *a,base;
	efg *e;
	e=static_cast<efg*>(&base);//base pointer can point to derived object reference by casting derived reference object to base pointer.
	e->puta(15);
	cout<<e->geta()<<endl;//it calls derived geta function.
	cout<<e->abc::geta()<<endl;//if you explicitly want to call base geta function without making virtual geta function.
	e->print();

}
	
