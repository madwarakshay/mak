#include<iostream>
#include<vector>
using namespace std;
class abc
{
	public:
		vector<int>a;
		
		int b;
		void put_matrix(int l)
		{
			b=l;
			int k;
			for(int i=0;i<b;i++)
			{
			cin>>k;
			a.push_back(k);
			}
		}
		void get_matrix()
		{
			cout<<"elements are :"<<endl;
			for(int i=0;i<b;i++)
			{
				cout<<a[i]<<" ";
			}
		}
		class iiterator
		{
			public:
				int *p;
				iiterator()
				{

				}
				iiterator(int *l)
				{
					p=l;
				}
				iiterator operator++(int x)
				{
					return p++;
				}
				int operator*()
				{
					return *p;
				}
				int operator!=(const iiterator& n)
				{
					if(p!=n.p)
						return 1;
					else
						return 0;
				}
				iiterator operator=(iiterator s)
				{
				
				cout<<"in = operator"<<endl;
				p=s.p;
				}
		};
		iiterator begin()
		{
			return &a[0];
		}
		iiterator end()
		{
			return &a[b];
		}
		int size()
		{
			return b;
		}
};
int main()
{
	abc a;
	a.put_matrix(5);
	a.get_matrix();
	cout<<endl;
	abc::iiterator p;
	for(p=a.begin();p!=a.end();p++)
	cout<<*p<<" ";
	cout<<"size : ";
	cout<<a.size()<<endl;
}
