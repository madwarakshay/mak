#include<iostream>
using namespace std;
class abc
{
	public:
		int *p;
		abc(int a)
		{
			p=new int;
			*p=a;
		}
		int geta()
		{
			return *p;
		}
		void seta(int a)
		{
			*p=a;
		}
		abc(abc &n)//deep copy.
		{
			p=new int;
			*p=n.geta();
		}
};
int main()
{
	abc a(10);
//	abc b=a;//shallow copy.
	abc b(a);
	cout<<a.geta()<<endl;
	cout<<b.geta()<<endl;
	a.seta(5);
	cout<<a.geta()<<endl;
	cout<<b.geta()<<endl;

}

