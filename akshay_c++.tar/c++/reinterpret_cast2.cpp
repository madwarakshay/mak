#include<iostream>
#include<iomanip>
using namespace std;
class a
{
	public:
		void funa()
		{
			cout<<"in class a"<<endl;
		}
};
class b
{
	public:
		void funb()
		{
			cout<<" in class b"<<endl;
		}
};
int main()
{
	b* x=new b();
	a* c=reinterpret_cast<a*>(x);
	cout.setf(ios::fixed);
	cout<<&c<<endl;
	cout<<&x<<endl;
	c->funa();
	x->funb();
}


