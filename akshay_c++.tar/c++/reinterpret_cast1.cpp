#include<iostream>
using namespace std;
class abc
{
	public:
		int a;
		float b;
		char c;
};
int main()
{
	abc b;
		b.a=10;
		b.b=10.25;
		b.c='a';
	int *p= reinterpret_cast<int *>(&b);
	cout<<*p<<endl;
	cout<<" size :"<<sizeof(b)<<endl;
	p++;
	float *f=reinterpret_cast<float *>(p);
	cout<<*f<<endl;
	cout<<" size :"<<sizeof(p)<<endl;
	f++;
	char *c=reinterpret_cast<char *>(f);
	cout<<*c<<endl;
	cout<<" size :"<<sizeof(f)<<endl;
//	c++;
}
