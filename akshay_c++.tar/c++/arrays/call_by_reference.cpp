#include<iostream>
using namespace std;
void negative(int &i)
{
//	*i=-*i;
	i=20;
}
int main()
{
	int x=10;
//	negative(&x);
	negative(x);/* it is reference operator usage we no need to use * in calllin g function , the overall reference of x is sent to negative function */
	cout<<"negative value is :"<<x<<endl;
}
