#include<iostream>
using namespace std;
class abc
{
	int i;
	public:
	void set_val(int n)
	{
		i=n;
	}
	int get_val(void)
	{
		return i;
	}
};
int main()
{
	abc a[4];
	for(int i=0;i<4;i++)
		a[i].set_val(i+1);
	for(int i=0;i<4;i++)
	{
		cout<<a[i].get_val()<<endl;
	}
}
