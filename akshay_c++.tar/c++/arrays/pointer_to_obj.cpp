#include<iostream>
using namespace std;
class abc
{
	int i;
	public:
	abc(int n)
	{
		i=n;
	}
	int get_val(void)
	{
		return i;
	}
};
int main()
{
	abc a(10),*p;
	p=&a;
	cout<<"value :"<<p->get_val()<<endl;
}
