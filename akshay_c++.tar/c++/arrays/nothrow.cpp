#include<iostream>
#include<new>
#include<cstring>
using namespace std;
class details
{
	char name[40];
	int balance;
	public:
	void set_val(int n,char *s)
	{
		strcpy(name,s);
		balance=n;
	}
	void get_val(int &n,char *s)
	{
		n=balance;
		strcpy(s,name);
	}
};
int main()
{
	details *p;
	char s[40];
	int n;
	p=new(nothrow)details;/* new on failure throws any value so to make it to give null on failure we have to use nothrow  */
	if(!p)
		cout<<"allocation failed"<<endl;
	p->set_val(50,"akshay");
	p->get_val(n,s);
	cout<<s<<"amount in account is :"<<n<<endl;
	delete p;
	return 0;
}
