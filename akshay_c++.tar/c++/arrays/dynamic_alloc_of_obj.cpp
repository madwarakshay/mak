#include<iostream>
#include<new>
#include<cstring>
using namespace std;
class details
{
	char name[40];
	double bal;
	public:
	void set_val(double n,char *s)
	{
		bal=n;
		strcpy(name,s);
	}
	void get_val(double &n, char *s)
	{
		n=bal;
		strcpy(s,name);
	}
};
int main()
{
	details *a;
	char s[40];
	double n;
	try
	{
		a=new details;
	}
	catch(bad_alloc xa)
	{
		cout<<"allocation failed"<<endl;
		return 1;
	}
	a->set_val(123.45, "akshay");
	a->get_val(n,s);
	cout<<"the current balance is  :"<<n<<endl;
	cout<<"the name of account holder is  :"<<s<<endl;
	delete a;
	return 0;
}

