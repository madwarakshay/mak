#include<iostream>
using namespace std;
class abc 
{
	int i;
	public:
	abc(int n)
	{
		i=n;
	}
	~abc()
	{
		cout<<"i value :"<<i<<endl;
	}
};
int main()
{
	abc a[4]={2,3,4,5};
}
