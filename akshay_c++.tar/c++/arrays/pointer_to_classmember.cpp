#include<iostream>
using namespace std;
class abc
{
	public:
	int i;
	void set_val(int n)
	{
		i=n;
	}
	int get_val(void)
	{
		return i;
	}
};
int main()
{
	abc  a;
	int abc::*data;
	int (abc::*fun)();
	void (abc::*fun1)(int);
	fun1=&abc::set_val;
	(a.*fun1)(10);
cout<<"i val in a :"<<a.get_val()<<endl;
	
//a.set_val(10);
data=&abc::i;
cout<<"i val in a :"<<a.*data<<endl;
fun=&abc::get_val;
cout<<"i val in a through fun :"<<(a.*fun)()<<endl; */
}
	
