#include<iostream>
using namespace std;
class base 
{
	int i;
	public:
	void set_val(int n)
	{
		i=n;
	}
	int get_val(void)
	{
		return i;
	}
};
class derived : public base
{
	int j;
	public:
	void set_j(int n)
	{
		j=n;
	}
	int get_j(void)
	{
		return j;
	}
};
int main()
{
	base *b;
	derived d;
	b=&d;
	b->set_val(6);
	cout<<"the value:"<<b->get_val()<<endl;
	((derived *)b)->set_j(5);  /* this both lines are errors . we cant access the variables represented in derived class through base pointer  */
	cout<<"the value:"<<((derived *)b)->get_j()<<endl;/* to set and get the values we have to typecast the base pointed as derived pointer */
}
