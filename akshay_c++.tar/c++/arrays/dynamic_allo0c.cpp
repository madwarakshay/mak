#include<iostream>
#include<new>
using namespace std;
int main()
{
	int *p;
	try
	{
	//	p=new int;
		p=new int(50);/* we can initialise the value directly also*/
	}
	catch(bad_alloc xa)
	{
		cout<<"bad allocation"<<endl;
		return 1;
	}
//	*p=20;
	cout<<"the value is  :"<<*p<<endl;
	delete p;
	return 0;
}
