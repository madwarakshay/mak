#include<iostream>
using namespace std;
void print(char * str)
{
	cout<<str<<endl;
}
int main()
{
	const char *s="abcedfgh";
	print(const_cast<char *>(s));
}

