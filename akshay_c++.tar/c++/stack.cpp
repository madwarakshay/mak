#include<iostream>
using namespace std;
class stack
{
	int stck[10];
	int top;
	public:
	void init();
	void push(int i);
	int pop(void);
};
void stack :: init()
{
top=0;
}
void stack :: push(int i)
{
	if(top==10)
	{
		cout<<"stack is full"<<"\n";
	}
	else
	{
		stck[top]=i;
		top++;
	}
}
int stack::pop()
{
	if(top==0)
	{
		cout<<"stack is empty"<<"\n";
	}
	else
	{
		top--;
	}
		return(stck[top]);
}
int main()
{
	stack s1,s2;
	s1.init();
	s2.init();
	s1.push(4);
	s2.push(5);
	cout<<"poped from s1 is   :"<<s1.pop()<<"\n";
	cout<<"poped from s2 is   :"<<s2.pop()<<"\n";
	return(0);
}
	
	
