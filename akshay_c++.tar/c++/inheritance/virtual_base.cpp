#include<iostream>
using namespace std;
class base
{
	public:
		int i;
};
class derived1 : public base
{
	public:
	int k;
};
class derived2 : public base
{
	public:
		int l;
};
class derived3 : public derived1,public derived2
{
	public:
		int sum;
};
int main()
{
	derived3 d;
//	d.i=10  /* this gives ambigious because derived3 inherited from both derived 1 and 2 which both are inherited from base so derived3 has two copies of base class so d.i =10 wont say which i (derived 1 or 2) so we can mention as below to remove ambigious  */
	d.derived2::i=10;
	cout<<d.derived2::i<<endl;

}
