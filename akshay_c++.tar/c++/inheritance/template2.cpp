#include<iostream>
using namespace std;
template<class x>
class one
{
	x a;
	public:
	one()
	{
	}
	void put(x z)
	{
		a=z;
	}
	one(x b)
	{
		a=b;
	}
	void show()
	{
		cout<<a<<endl;
	}
};
template<class x>
class derived : public one<x>
{
	int b;
	
	public:
	derived()
	{
	}
	void put(int n)
	{
		b=n;
	}
	derived(int d):one<x>(d)
	{
		b=d;
	}
	void showd()
	{
		cout<<b<<endl;
		
	}
};
int main()
{
	cout<<sizeof(one<int>)<<endl;
	one<char>b('c');
	b.show();
	derived<int> d(10);
//	d.put(10);
//	d.one<int>::put(5);
//	derived<int,float> d(4,5,7.0);
	d.show();
	d.showd();
	cout<<sizeof(d)<<endl;
}
