#include<iostream>
using namespace std;
class base
{
	int a;
	protected:   /* this variables will become private in inherited class  */
	int i,j;
	public:
	void set(int m,int n,int o)
	{

		a=m;
		i=n;
		j=o;
	}
	void show()
	{
		cout<<"a  :"<<a<<"  "<<"i  :"<<i<<"  "<<"j  :"<<j<<endl;
	}
};
class derived:protected base
{
	int k;
	public:
	void setk(int m,int n,int o)
	{
		set(m,n,o);
		k=i*j;
	}
	void show1()
	{
		show();
		cout<<"k value is :"<<k<<endl;
	}
};
int main()
{
	derived d;
	d.setk(1,2,3);
	d.show1();
}


