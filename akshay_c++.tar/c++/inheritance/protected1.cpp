#include<iostream>
using namespace std;
class base
{
	int a;
	protected:   /* this variables will become private in inherited class  */
	int i,j;
	public:
	void set(int m,int n,int o)
	{

		a=m;
		i=n;
		j=o;
	}
	void show()
	{
		cout<<a<<"  "<<i<<"  "<<j<<endl;
	}
};
class derived:public base
{
	int k;
	public:
	void setk()
	{
		k=i*j;
	}
	void show1()
	{
		cout<<k<<endl;
	}
};
class derived2 :public derived
{
	int m;
	public:
	void setm()
	{
		m=i+j;
	}
	void showm()
	{
		cout<<"m value is  :"<<m<<endl;
	}
};
int main()
{
	derived d;
	d.set(1,2,3);
	d.setk();
	d.show();
	d.show1();
	derived2 d1;
	d1.set(4,5,6);
	d1.setm();
	d1.showm();
}


