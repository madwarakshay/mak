#include<iostream>
using namespace std;
template<class x>
class one
{
	x a;
	public:
	one()
	{
	}
	void put(x z)
	{
		a=z;
	}
	one(x b)
	{
		a=b;
	}
	void show()
	{
		cout<<a<<endl;
	}
};
template<class x, class y>
class derived : public one<x>
{
	x b;
	y c;
	public:
	derived()
	{
	}
	void put(y n)
	{
		c=n;
	}
	derived(x d,y u):one<x>(d)
	{
		b=d;
		c=u;
	}
	void showd()
	{
		//cout<<b<<endl;
		cout<<c<<endl;
	}
};
int main()
{
	one<char>b('c');
	b.show();
	derived<int,char> d;
	d.put('c');
	d.one<int>::put(5);
//	derived<int,float> d(4,5,7.0);
	d.show();
	d.showd();
}
