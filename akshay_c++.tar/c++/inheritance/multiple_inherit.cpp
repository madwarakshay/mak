#include<iostream>
using namespace std;
class base1
{
	protected:
		int a;
	public:
		void showa()
		{
			cout<<"a is :"<<a<<endl;
		}
};
class base2
{
	protected:
		int b;
	public:
		void showb()
		{
			cout<<"b is  :"<<b<<endl;
		}
};
class derived: protected base1,protected base2
{
	public:
		void set(int m,int n)
		{
			a=m;
			b=n;
		}
		void show(void)
		{
			showa();
			showb();
		}
};
int main()
{
	derived d;
	d.set(2,3);
	d.show();
}
