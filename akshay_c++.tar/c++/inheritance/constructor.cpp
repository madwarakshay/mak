#include<iostream>
using namespace std;
class base
{
	int a;
	public:
	base(int i)
	{
		a=i;
	}
	int geta()
	{
		return a;
	}
};
class derived : public base
{
	int a;
	public:
	derived(int i,int j):base(i)
	{
		a=j;
	}
	int  geta()
	{
		return a;
	}
};
int main()
{
	derived d(5,4);
	cout<<"a val of base is :  "<<d.base::geta()<<endl;
	cout<<"a val of derived is :"<<d.geta()<<endl;
}
