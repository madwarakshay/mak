#include<iostream>
using namespace std;
class base
{
	int a;
	public:
	void seta(int i)
	{
		a=i;
	}
	int geta()
	{
		return a;
	}
};
class derived:private base
{
	public:
		base::seta;
		base::geta;
		void show()
		{
			int b=geta();
			cout<<"a is  :"<<b<<endl;
		}
};
int main()
{
	derived d;
	d.seta(5);
int b=d.geta();
cout<<"b is :"<<b<<endl;
}
