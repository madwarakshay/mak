#include<iostream>
using namespace std;
class base 
{
	public:
		base()
		{
			cout<<"constructing base"<<endl;
		}
		~base()
		{
			cout<<"destructing base"<<endl;
		}
};
class derived:public base
{
	public:
	
		derived()
		{
			cout<<"constructing derived"<<endl;
		}
		~derived()
		{
			cout<<"destructing derived"<<endl;
		}
};
int main()
{
	derived d;
	return 0;
}
