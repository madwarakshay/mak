#include<iostream>
using namespace std;
class base
{
	public:
		int i;
};
class derived1 : virtual public base
{
	public:
	int k;
};
class derived2 : virtual public base   /* by keeping virtual when derived it gives only one copy of base to derived3 so no ambigious occurs */
{
	public:
		int l;
};
class derived3 : public derived1,public derived2
{
	public:
		int sum;
};
int main()
{
	derived3 d;
//	d.i=10  /* this gives ambigious because derived3 inherited from both derived 1 and 2 which both are inherited from base so derived3 has two copies of base class so d.i =10 wont say which i (derived 1 or 2) so we can mention as below to remove ambigious   "so by keeping virtual when inherited we can use d.i as follows"  */
//	d.derived2::i=10;
//	cout<<d.derived2::i<<endl;
	d.i=10;//not ambigious
	d.k=20;
	d.l=30;
	d.sum=d.i+d.k+d.l;
	cout<<"sum is :"<<d.sum<<endl;
}


