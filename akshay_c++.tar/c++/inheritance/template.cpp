#include<iostream>
using namespace std;
template<class x>
class one
{
	x a;
	public:
	one()
	{
	}
	one(x b)
	{
		a=b;
	}
	void show()
	{
		cout<<a<<endl;
	}
};
template<class x, class y>
class derived : public one<x>
{
	x b;
	y c;
	public:
	derived(x d,x m,y u):one<x>(m)
	{
		b=d;
		c=u;
	}
	void showd()
	{
		cout<<b<<endl;
//	cout.setf(ios::fixed);
		cout<<c<<endl;
	}
};
int main()
{
	one<char>b('c');
	b.show();
//	cout.setf(ios::fixed);
	derived<int,float> d(4,5,7.0);
	d.show();
	d.showd();
}
